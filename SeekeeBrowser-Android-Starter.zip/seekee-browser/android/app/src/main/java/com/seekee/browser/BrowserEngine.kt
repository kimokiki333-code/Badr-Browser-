package com.seekee.browser

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.mozilla.geckoview.ExperimentalGeckoViewApi
import org.mozilla.geckoview.GeckoPreferenceController
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController

class BrowserTab(
    val id: Long,
    val session: GeckoSession,
    val privateMode: Boolean
) {
    var address by mutableStateOf("")
    var isHome by mutableStateOf(true)
}

data class ExtensionPrompt(
    val extension: WebExtension,
    val permissions: List<String>,
    val origins: List<String>,
    internal val result: GeckoResult<WebExtension.PermissionPromptResponse>
)

/**
 * GeckoView-backed browser engine. All navigation is issued through GeckoView;
 * app UI code must never fetch a page itself (especially while Tor is enabled).
 */
@OptIn(ExperimentalGeckoViewApi::class)
class BrowserEngine(context: Context) {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())

    val runtime: GeckoRuntime = GeckoRuntime.create(
        appContext,
        GeckoRuntimeSettings.Builder()
            .extensionsProcessEnabled(true)
            .extensionsWebAPIEnabled(true)
            .build()
    )

    var tabs by mutableStateOf<List<BrowserTab>>(emptyList())
        private set
    var activeTabId by mutableLongStateOf(0L)
        private set
    var ready by mutableStateOf(false)
        private set
    var pendingExtensionPrompt by mutableStateOf<ExtensionPrompt?>(null)
        private set

    private var nextTabId = 1L
    val activeTab: BrowserTab?
        get() = tabs.firstOrNull { it.id == activeTabId }

    init {
        // Clear a persisted proxy on startup before creating a navigable tab.
        // Tor mode is always opt-in for each app launch.
        setDirectProxy { result ->
            mainHandler.post {
                ready = result.isSuccess
                if (result.isSuccess && tabs.isEmpty()) newTab(privateMode = false)
            }
        }
    }

    fun newTab(privateMode: Boolean = activeTab?.privateMode ?: false): BrowserTab {
        val settings = GeckoSessionSettings.Builder()
            .useTrackingProtection(true)
            .usePrivateMode(privateMode)
            .build()
        val session = GeckoSession(settings)
        session.open(runtime)
        installPermissionPrompt(session)

        val tab = BrowserTab(nextTabId++, session, privateMode)
        tabs = tabs + tab
        activeTabId = tab.id
        return tab
    }

    fun selectTab(tabId: Long) {
        if (tabs.any { it.id == tabId }) activeTabId = tabId
    }

    fun closeTab(tabId: Long) {
        val closing = tabs.firstOrNull { it.id == tabId } ?: return
        closing.session.stop()
        closing.session.close()
        val remaining = tabs.filterNot { it.id == tabId }
        tabs = remaining
        if (remaining.isEmpty()) {
            newTab(privateMode = closing.privateMode)
        } else if (activeTabId == tabId) {
            activeTabId = remaining.last().id
        }
    }

    fun closeAllTabs() {
        tabs.forEach {
            runCatching { it.session.stop() }
            runCatching { it.session.close() }
        }
        tabs = emptyList()
        activeTabId = 0L
    }

    fun resetForRoute(privateMode: Boolean) {
        closeAllTabs()
        newTab(privateMode = privateMode)
    }

    fun navigate(url: String) {
        val tab = activeTab ?: newTab()
        tab.address = url
        tab.isHome = false
        tab.session.loadUri(url)
    }

    fun showHome() {
        activeTab?.let { tab ->
            tab.session.stop()
            tab.session.loadUri("about:blank")
            tab.address = ""
            tab.isHome = true
        }
    }

    fun goBack() = activeTab?.session?.goBack()
    fun goForward() = activeTab?.session?.goForward()
    fun reload() = activeTab?.session?.reload()

    fun setTrackingProtection(enabled: Boolean) {
        activeTab?.session?.settings?.useTrackingProtection = enabled
    }

    fun installAddon(downloadUrl: String, onResult: (String?) -> Unit) {
        val controller = activeTab?.session?.webExtensionController
        if (controller == null) {
            onResult("Open a browser tab before installing an add-on.")
            return
        }
        controller.install(downloadUrl, WebExtensionController.INSTALLATION_METHOD_MANAGER)
            .accept(
                { extension ->
                    val name = extension.metaData.name ?: extension.id
                    onResult("Installed $name.")
                },
                { error -> onResult(error.message ?: "Add-on installation failed.") }
            )
    }

    fun answerExtensionPrompt(prompt: ExtensionPrompt, allow: Boolean, allowInPrivate: Boolean = false) {
        runCatching {
            prompt.result.complete(
                WebExtension.PermissionPromptResponse(
                    allow,
                    allowInPrivate,
                    false // do not grant technical/interaction data collection
                )
            )
        }
        if (pendingExtensionPrompt?.result === prompt.result) pendingExtensionPrompt = null
    }

    fun setTorProxy(port: Int, callback: (Result<Unit>) -> Unit) {
        if (port !in 1..65535) {
            callback(Result.failure(IllegalArgumentException("Tor returned an invalid SOCKS port.")))
            return
        }
        setPreferences(
            listOf(
                GeckoPreferenceController.SetGeckoPreference.setStringPref(
                    "network.proxy.socks", "127.0.0.1", USER_PREF
                ),
                GeckoPreferenceController.SetGeckoPreference.setIntPref(
                    "network.proxy.socks_port", port, USER_PREF
                ),
                GeckoPreferenceController.SetGeckoPreference.setIntPref(
                    "network.proxy.socks_version", 5, USER_PREF
                ),
                GeckoPreferenceController.SetGeckoPreference.setBoolPref(
                    "network.proxy.socks_remote_dns", true, USER_PREF
                ),
                GeckoPreferenceController.SetGeckoPreference.setStringPref(
                    "network.proxy.no_proxies_on", "", USER_PREF
                ),
                GeckoPreferenceController.SetGeckoPreference.setBoolPref(
                    "network.proxy.failover_direct", false, USER_PREF
                ),
                GeckoPreferenceController.SetGeckoPreference.setBoolPref(
                    "media.peerconnection.enabled", false, USER_PREF
                ),
                // Activate the proxy only after its settings have been supplied.
                GeckoPreferenceController.SetGeckoPreference.setIntPref(
                    "network.proxy.type", 1, USER_PREF
                )
            ),
            callback
        )
    }

    fun setDirectProxy(callback: (Result<Unit>) -> Unit) {
        setPreferences(
            listOf(
                GeckoPreferenceController.SetGeckoPreference.setIntPref(
                    "network.proxy.type", 0, USER_PREF
                ),
                GeckoPreferenceController.SetGeckoPreference.setBoolPref(
                    "media.peerconnection.enabled", true, USER_PREF
                )
            ),
            callback
        )
    }

    /** Keep the engine blocked if Tor fails; never silently fall back to direct. */
    fun setDeadProxy(callback: (Result<Unit>) -> Unit = {}) {
        setPreferences(
            listOf(
                GeckoPreferenceController.SetGeckoPreference.setStringPref(
                    "network.proxy.socks", "127.0.0.1", USER_PREF
                ),
                GeckoPreferenceController.SetGeckoPreference.setIntPref(
                    "network.proxy.socks_port", 1, USER_PREF
                ),
                GeckoPreferenceController.SetGeckoPreference.setIntPref(
                    "network.proxy.socks_version", 5, USER_PREF
                ),
                GeckoPreferenceController.SetGeckoPreference.setBoolPref(
                    "network.proxy.socks_remote_dns", true, USER_PREF
                ),
                GeckoPreferenceController.SetGeckoPreference.setBoolPref(
                    "network.proxy.failover_direct", false, USER_PREF
                ),
                GeckoPreferenceController.SetGeckoPreference.setIntPref(
                    "network.proxy.type", 1, USER_PREF
                )
            ),
            callback
        )
    }

    private fun setPreferences(
        preferences: List<GeckoPreferenceController.SetGeckoPreference<*>>,
        callback: (Result<Unit>) -> Unit
    ) {
        GeckoPreferenceController.setGeckoPrefs(preferences).accept(
            { applied ->
                mainHandler.post {
                    val failedPrefs = applied.filterValues { succeeded -> !succeeded }.keys
                    if (failedPrefs.isEmpty()) callback(Result.success(Unit))
                    else callback(Result.failure(IllegalStateException("Could not set Gecko preferences: ${failedPrefs.joinToString()}")))
                }
            },
            { error -> mainHandler.post { callback(Result.failure(error)) } }
        )
    }

    private fun installPermissionPrompt(session: GeckoSession) {
        session.webExtensionController.promptDelegate = object : WebExtensionController.PromptDelegate {
            override fun onInstallPromptRequest(
                extension: WebExtension,
                permissions: Array<String>,
                origins: Array<String>,
                dataCollectionPermissions: Array<String>
            ): GeckoResult<WebExtension.PermissionPromptResponse> {
                val result = GeckoResult<WebExtension.PermissionPromptResponse>()
                mainHandler.post {
                    pendingExtensionPrompt = ExtensionPrompt(
                        extension = extension,
                        permissions = permissions.toList(),
                        origins = origins.toList(),
                        result = result
                    )
                }
                return result
            }
        }
    }

    fun close() {
        closeAllTabs()
        runCatching { runtime.shutdown() }
    }

    companion object {
        private const val USER_PREF = GeckoPreferenceController.PREF_BRANCH_USER

        fun normalizeAddress(input: String): String {
            val value = input.trim()
            if (value.isEmpty()) return ""
            if (value.matches(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://.*"))) return value
            if (value.startsWith("about:") || value.startsWith("file:") || value.startsWith("resource:")) return value
            if (value == "localhost" || value.startsWith("localhost:")) return "http://$value"
            val looksLikeHost = !value.contains(' ') && (value.contains('.') || value.endsWith(".onion"))
            return if (looksLikeHost) "https://$value"
            else "https://duckduckgo.com/?q=${Uri.encode(value)}"
        }

        fun isOnionAddress(url: String): Boolean {
            val host = runCatching { Uri.parse(url).host?.lowercase() }.getOrNull() ?: return false
            return host.endsWith(".onion")
        }
    }
}
