package com.seekee.browser

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import org.torproject.jni.TorService

/** A browser-only Tor route. It is not a device-wide VPN. */
class TorController(
    private val context: Context,
    private val engine: BrowserEngine
) {
    enum class State { OFF, STARTING, ON, STOPPING, ERROR }

    var state by mutableStateOf(State.OFF)
        private set
    var message by mutableStateOf("Tor is off")
        private set

    private var service: TorService? = null
    private var bound = false
    private var receiverRegistered = false
    private var requested = false
    private var failureLatched = false
    private var torOnBroadcastSeen = false
    private var applyingTorRoute = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != TorService.ACTION_STATUS) return
            if (intent.getStringExtra(TorService.EXTRA_SERVICE_PACKAGE_NAME) != context.packageName) return
            when (intent.getStringExtra(TorService.EXTRA_STATUS)) {
                TorService.STATUS_STARTING -> {
                    if (requested) setState(State.STARTING, "Connecting to Tor…")
                }
                TorService.STATUS_ON -> {
                    torOnBroadcastSeen = true
                    maybeApplyTorRoute()
                }
                TorService.STATUS_STOPPING -> {
                    if (requested) failClosed("Tor stopped before a safe route was ready.")
                }
                TorService.STATUS_OFF -> {
                    if (requested) failClosed("Tor disconnected. Browser traffic is blocked until you retry or turn Tor off.")
                    else if (state != State.STOPPING && !failureLatched) setState(State.OFF, "Tor is off")
                }
            }
        }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = (binder as? TorService.LocalBinder)?.service
            maybeApplyTorRoute()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            if (requested) failClosed("Tor service disconnected. Browser traffic is blocked.")
        }
    }

    fun start() {
        if (state == State.ON || state == State.STARTING || state == State.STOPPING) return
        requested = true
        failureLatched = false
        torOnBroadcastSeen = false
        applyingTorRoute = false
        setState(State.STARTING, "Starting Tor. No pages will load until the Tor route is ready.")
        engine.closeAllTabs()
        registerReceiverIfNeeded()

        val intent = Intent(context, TorService::class.java)
        bound = runCatching {
            context.bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }.getOrDefault(false)
        if (!bound) failClosed("Could not start the embedded Tor service.")
    }

    fun stop() {
        if (state == State.OFF && !bound) return
        requested = false
        failureLatched = false
        applyingTorRoute = false
        setState(State.STOPPING, "Turning Tor off safely…")
        engine.closeAllTabs()
        engine.setDirectProxy { result ->
            if (result.isSuccess) {
                releaseService()
                engine.resetForRoute(privateMode = false)
                setState(State.OFF, "Tor is off")
            } else {
                engine.setDeadProxy()
                setState(State.ERROR, "Could not clear the Tor route. Traffic remains blocked; restart the app or retry.")
            }
        }
    }

    private fun maybeApplyTorRoute() {
        if (!requested || !torOnBroadcastSeen || applyingTorRoute) return
        val torService = service ?: return
        val socksPort = torService.socksPort
        if (socksPort !in 1..65535) {
            failClosed("Tor is up, but its local SOCKS port was unavailable.")
            return
        }
        applyingTorRoute = true
        setState(State.STARTING, "Applying Tor routing and DNS protections…")
        engine.setTorProxy(socksPort) { result ->
            if (!requested) return@setTorProxy
            if (result.isSuccess) {
                engine.resetForRoute(privateMode = true)
                setState(State.ON, "Tor connected · onion addresses can now be opened")
            } else {
                failClosed("Could not apply Tor routing. No direct fallback will be used.")
            }
        }
    }

    private fun failClosed(reason: String) {
        if (failureLatched) return
        failureLatched = true
        requested = false
        applyingTorRoute = false
        engine.closeAllTabs()
        engine.setDeadProxy()
        setState(State.ERROR, reason)
        releaseService()
    }

    private fun registerReceiverIfNeeded() {
        if (receiverRegistered) return
        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(TorService.ACTION_STATUS),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        receiverRegistered = true
    }

    private fun releaseService() {
        if (bound) {
            runCatching { context.unbindService(connection) }
            bound = false
        }
        service = null
        if (receiverRegistered) {
            runCatching { context.unregisterReceiver(receiver) }
            receiverRegistered = false
        }
    }

    fun dispose() {
        requested = false
        engine.closeAllTabs()
        releaseService()
    }

    private fun setState(newState: State, detail: String) {
        state = newState
        message = detail
    }
}
