package com.seekee.browser

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.mozilla.geckoview.GeckoView

private val Night = Color(0xFF0B0E16)
private val Panel = Color(0xFF141927)
private val PanelRaised = Color(0xFF1B2233)
private val Accent = Color(0xFFAA91FF)
private val Mint = Color(0xFF73E0C0)
private val Muted = Color(0xFFA0A8BB)

class MainActivity : ComponentActivity() {
    private lateinit var engine: BrowserEngine
    private lateinit var tor: TorController
    private lateinit var store: BrowserStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 14, 22)
        window.navigationBarColor = android.graphics.Color.rgb(11, 14, 22)
        engine = BrowserEngine(applicationContext)
        tor = TorController(this, engine)
        store = BrowserStore(applicationContext)
        setContent {
            SeekeeBrowserApp(
                engine = engine,
                tor = tor,
                store = store
            )
        }
    }

    override fun onDestroy() {
        tor.dispose()
        engine.close()
        super.onDestroy()
    }
}

private enum class BrowserPage { BROWSER, BOOKMARKS, HISTORY, DOWNLOADS, ADDONS, VPN, SETTINGS, TABS, MENU }

@Composable
private fun SeekeeBrowserApp(engine: BrowserEngine, tor: TorController, store: BrowserStore) {
    var currentPage by remember { mutableStateOf(BrowserPage.BROWSER) }
    var address by remember { mutableStateOf("") }
    var homeQuery by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    var shieldEnabled by remember { mutableStateOf(true) }
    var darkTheme by remember { mutableStateOf(true) }
    var dataRevision by remember { mutableIntStateOf(0) }
    val activeTab = engine.activeTab
    val context = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current

    LaunchedEffect(activeTab?.id) {
        address = activeTab?.address.orEmpty()
    }

    val onNavigate: (String) -> Unit = { typed ->
        val normalized = BrowserEngine.normalizeAddress(typed)
        if (normalized.isBlank()) {
            errorMessage = "Enter a search or web address."
        } else if (!engine.ready) {
            errorMessage = "The browser engine is still starting."
        } else if (tor.state == TorController.State.STARTING || tor.state == TorController.State.STOPPING || tor.state == TorController.State.ERROR) {
            errorMessage = "Traffic is blocked while the privacy route is changing or unavailable."
        } else if (BrowserEngine.isOnionAddress(normalized) && tor.state != TorController.State.ON) {
            errorMessage = "Connect Tor first. No .onion request was sent."
        } else {
            errorMessage = ""
            engine.navigate(normalized)
            address = normalized
            engine.activeTab?.let { tab -> store.addVisit(normalized, privateMode = tab.privateMode) }
            dataRevision++
            currentPage = BrowserPage.BROWSER
            keyboard?.hide()
        }
    }

    val palette = if (darkTheme) {
        darkColorScheme(
            primary = Accent,
            secondary = Mint,
            background = Night,
            surface = Panel,
            onPrimary = Color(0xFF17122A),
            onBackground = Color(0xFFF4F2FC),
            onSurface = Color(0xFFF4F2FC)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF6549C8),
            secondary = Color(0xFF087E66),
            background = Color(0xFFF5F3FB),
            surface = Color.White,
            onBackground = Color(0xFF191626),
            onSurface = Color(0xFF191626)
        )
    }

    MaterialTheme(colorScheme = palette) {
        Column(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            BrowserHeader(tor = tor, onTorClick = {
                when (tor.state) {
                    TorController.State.OFF -> tor.start()
                    TorController.State.ON -> tor.stop()
                    TorController.State.ERROR -> tor.stop()
                    else -> Unit
                }
            }, onMenuClick = { currentPage = BrowserPage.MENU })

            if (currentPage == BrowserPage.BROWSER) {
                AddressBar(
                    address = address,
                    onAddressChange = { address = it },
                    onGo = { onNavigate(address) },
                    onBack = { engine.goBack() },
                    onForward = { engine.goForward() },
                    onReload = { engine.reload() },
                    onBookmark = {
                        val current = engine.activeTab?.address.orEmpty()
                        if (current.isNotBlank()) {
                            store.addBookmark(current)
                            dataRevision++
                            Toast.makeText(context, "Saved to bookmarks", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Open a page first", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }

            if (errorMessage.isNotBlank()) {
                ErrorBanner(errorMessage, onDismiss = { errorMessage = "" })
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (currentPage) {
                    BrowserPage.BROWSER -> {
                        if (!engine.ready) {
                            LoadingPanel("Preparing a clean browser session…")
                        } else if (activeTab == null || activeTab.isHome) {
                            StartPage(
                                query = homeQuery,
                                onQueryChange = { homeQuery = it },
                                onSearch = { onNavigate(homeQuery) },
                                shieldEnabled = shieldEnabled,
                                tor = tor,
                                onConnectTor = { if (tor.state == TorController.State.OFF) tor.start() },
                                onOpenBookmarks = { currentPage = BrowserPage.BOOKMARKS },
                                onOpenAddons = { currentPage = BrowserPage.ADDONS }
                            )
                        } else {
                            key(activeTab.id) {
                                AndroidView(
                                    factory = { viewContext -> GeckoView(viewContext).apply { setSession(activeTab.session) } },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                        if (tor.state == TorController.State.STARTING || tor.state == TorController.State.STOPPING || tor.state == TorController.State.ERROR) {
                            RouteGuardPanel(tor = tor, onReset = { tor.stop() })
                        }
                    }
                    BrowserPage.BOOKMARKS -> {
                        val entries = remember(dataRevision, currentPage) { store.bookmarks() }
                        EntryPanel(
                            title = "Bookmarks",
                            subtitle = "Saved on this device",
                            entries = entries,
                            emptyTitle = "Nothing saved yet",
                            emptyMessage = "Tap the star beside the address bar to keep a page here.",
                            onOpen = { onNavigate(it) },
                            onRemove = { store.removeBookmark(it); dataRevision++ }
                        )
                    }
                    BrowserPage.HISTORY -> {
                        val entries = remember(dataRevision, currentPage) { store.history() }
                        EntryPanel(
                            title = "History",
                            subtitle = "Normal tabs only · private tabs are not recorded",
                            entries = entries,
                            emptyTitle = "No recent pages",
                            emptyMessage = "Pages you visit in normal tabs will appear here.",
                            onOpen = { onNavigate(it) },
                            onRemove = null,
                            onClear = { store.clearHistory(); dataRevision++ }
                        )
                    }
                    BrowserPage.DOWNLOADS -> DownloadsPanel()
                    BrowserPage.ADDONS -> AddonsPanel(
                        shieldEnabled = shieldEnabled,
                        onShieldChange = {
                            shieldEnabled = it
                            engine.setTrackingProtection(it)
                        },
                        onInstall = { downloadUrl ->
                            engine.installAddon(downloadUrl) { result ->
                                Toast.makeText(context, result, Toast.LENGTH_LONG).show()
                            }
                        }
                    )
                    BrowserPage.VPN -> VpnPanel()
                    BrowserPage.SETTINGS -> SettingsPanel(
                        shieldEnabled = shieldEnabled,
                        onShieldChange = {
                            shieldEnabled = it
                            engine.setTrackingProtection(it)
                        },
                        darkTheme = darkTheme,
                        onThemeChange = { darkTheme = it },
                        onClearHistory = { store.clearHistory(); dataRevision++ },
                        tor = tor
                    )
                    BrowserPage.TABS -> TabsPanel(
                        tabs = engine.tabs,
                        activeTabId = engine.activeTabId,
                        onSelect = { engine.selectTab(it); currentPage = BrowserPage.BROWSER },
                        onClose = { engine.closeTab(it) },
                        onNewTab = { engine.newTab(privateMode = tor.state == TorController.State.ON); currentPage = BrowserPage.BROWSER }
                    )
                    BrowserPage.MENU -> MenuPanel(
                        onSelect = { currentPage = it },
                        onNewTab = { engine.newTab(privateMode = tor.state == TorController.State.ON); currentPage = BrowserPage.BROWSER },
                        onPrivateTab = { engine.newTab(privateMode = true); currentPage = BrowserPage.BROWSER }
                    )
                }
            }

            BottomBar(currentPage = currentPage, onSelect = { currentPage = it })
        }

        engine.pendingExtensionPrompt?.let { prompt ->
            val name = prompt.extension.metaData.name ?: "Browser add-on"
            AlertDialog(
                onDismissRequest = { engine.answerExtensionPrompt(prompt, allow = false) },
                title = { Text("Install $name?") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Review what this extension can access before installing.")
                        if (prompt.permissions.isNotEmpty()) Text("Permissions: ${prompt.permissions.joinToString()}")
                        if (prompt.origins.isNotEmpty()) Text("Website access: ${prompt.origins.joinToString()}")
                        Text("The extension will not be granted access to private tabs by default.", color = Muted)
                    }
                },
                confirmButton = {
                    Button(onClick = { engine.answerExtensionPrompt(prompt, allow = true, allowInPrivate = false) }) {
                        Text("Install")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { engine.answerExtensionPrompt(prompt, allow = false) }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
private fun BrowserHeader(tor: TorController, onTorClick: () -> Unit, onMenuClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Night)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Accent),
            contentAlignment = Alignment.Center
        ) {
            Text("S", color = Color(0xFF191329), fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("SEEKee", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text("BROWSER", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
        }
        TorBadge(tor = tor, onClick = onTorClick)
        IconButton(onClick = onMenuClick) {
            Icon(Icons.Filled.Menu, contentDescription = "Open menu", tint = Color.White)
        }
    }
}

@Composable
private fun TorBadge(tor: TorController, onClick: () -> Unit) {
    val color = when (tor.state) {
        TorController.State.ON -> Mint
        TorController.State.STARTING, TorController.State.STOPPING -> Accent
        TorController.State.ERROR -> Color(0xFFFFB870)
        TorController.State.OFF -> Muted
    }
    val label = when (tor.state) {
        TorController.State.ON -> "TOR ON"
        TorController.State.STARTING -> "TOR…"
        TorController.State.STOPPING -> "STOPPING"
        TorController.State.ERROR -> "TOR ERROR"
        TorController.State.OFF -> "TOR OFF"
    }
    Surface(
        modifier = Modifier.clickable(enabled = tor.state != TorController.State.STARTING && tor.state != TorController.State.STOPPING, onClick = onClick),
        shape = CircleShape,
        color = color.copy(alpha = 0.13f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.55f))
    ) {
        Row(Modifier.padding(horizontal = 11.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Lock, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(5.dp))
            Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        }
    }
}

@Composable
private fun AddressBar(
    address: String,
    onAddressChange: (String) -> Unit,
    onGo: () -> Unit,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onReload: () -> Unit,
    onBookmark: () -> Unit
) {
    val keyboard = LocalSoftwareKeyboardController.current
    Row(
        Modifier
            .fillMaxWidth()
            .background(Night)
            .padding(start = 8.dp, end = 10.dp, bottom = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack, modifier = Modifier.size(38.dp)) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        IconButton(onClick = onForward, modifier = Modifier.size(38.dp)) {
            Icon(Icons.Filled.ArrowForward, contentDescription = "Forward", tint = Muted)
        }
        OutlinedTextField(
            value = address,
            onValueChange = onAddressChange,
            modifier = Modifier.weight(1f).heightIn(min = 50.dp),
            singleLine = true,
            placeholder = { Text("Search or type an address", fontSize = 13.sp, color = Muted) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
            shape = RoundedCornerShape(17.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { onGo(); keyboard?.hide() })
        )
        IconButton(onClick = onBookmark, modifier = Modifier.size(42.dp)) {
            Icon(Icons.Filled.BookmarkBorder, contentDescription = "Bookmark current page", tint = Accent)
        }
        IconButton(onClick = onReload, modifier = Modifier.size(38.dp)) {
            Icon(Icons.Filled.Refresh, contentDescription = "Reload", tint = Color.White)
        }
    }
}

@Composable
private fun StartPage(
    query: String,
    onQueryChange: (String) -> Unit,
    onSearch: () -> Unit,
    shieldEnabled: Boolean,
    tor: TorController,
    onConnectTor: () -> Unit,
    onOpenBookmarks: () -> Unit,
    onOpenAddons: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(6.dp))
        Text("Your web, your way.", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Text("Everyday browsing with privacy tools built in.", color = Muted)

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Search or enter a website") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                shape = RoundedCornerShape(18.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() })
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickLink("Bookmarks", Icons.Filled.Bookmarks, onOpenBookmarks, Modifier.weight(1f))
            QuickLink("Add-ons", Icons.Filled.Extension, onOpenAddons, Modifier.weight(1f))
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(22.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f))
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Shield, contentDescription = null, tint = if (shieldEnabled) Mint else Muted)
                    Spacer(Modifier.width(9.dp))
                    Text("Privacy shield", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Spacer(Modifier.weight(1f))
                    Text(if (shieldEnabled) "ON" else "OFF", color = if (shieldEnabled) Mint else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Text("GeckoView tracking protection is ${if (shieldEnabled) "enabled" else "paused"}. For stronger ad blocking, install a signed add-on from the add-ons screen.", color = Muted, fontSize = 13.sp)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(22.dp),
            border = BorderStroke(1.dp, Accent.copy(alpha = 0.18f))
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Lock, contentDescription = null, tint = Accent)
                    Spacer(Modifier.width(9.dp))
                    Text("Tor browsing", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Spacer(Modifier.weight(1f))
                    Text(if (tor.state == TorController.State.ON) "CONNECTED" else "OPTIONAL", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Text("Open .onion sites only after Tor reports a ready route. If the route fails, browsing stays blocked instead of falling back to your normal connection.", color = Muted, fontSize = 13.sp)
                if (tor.state == TorController.State.OFF) {
                    FilledTonalButton(onClick = onConnectTor) { Text("Connect to Tor") }
                } else {
                    Text(tor.message, color = Accent, fontSize = 12.sp)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Security, contentDescription = null, tint = Muted, modifier = Modifier.size(17.dp))
            Text("VPN provider connections are planned for a later version.", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun QuickLink(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = PanelRaised),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Accent, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun BottomBar(currentPage: BrowserPage, onSelect: (BrowserPage) -> Unit) {
    NavigationBar(containerColor = Night) {
        val items = listOf(
            Triple(BrowserPage.BROWSER, "Browse", Icons.Filled.Home),
            Triple(BrowserPage.BOOKMARKS, "Saved", Icons.Filled.BookmarkBorder),
            Triple(BrowserPage.ADDONS, "Add-ons", Icons.Filled.Extension),
            Triple(BrowserPage.VPN, "VPN", Icons.Filled.VpnKey),
            Triple(BrowserPage.MENU, "More", Icons.Filled.Menu)
        )
        items.forEach { (page, label, icon) ->
            NavigationBarItem(
                selected = currentPage == page,
                onClick = { onSelect(page) },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label, fontSize = 10.sp) },
                alwaysShowLabel = true
            )
        }
    }
}

@Composable
private fun ErrorBanner(message: String, onDismiss: () -> Unit) {
    Surface(color = Color(0xFF3A2631), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(message, modifier = Modifier.weight(1f), color = Color(0xFFFFD9DF), fontSize = 12.sp)
            IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Dismiss", tint = Color(0xFFFFD9DF), modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun RouteGuardPanel(tor: TorController, onReset: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Night.copy(alpha = 0.96f)
    ) {
        Column(
            Modifier.fillMaxSize().padding(28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.Lock, contentDescription = null, tint = if (tor.state == TorController.State.ERROR) Color(0xFFFFB870) else Accent, modifier = Modifier.size(42.dp))
            Spacer(Modifier.height(16.dp))
            Text(if (tor.state == TorController.State.ERROR) "Traffic blocked" else "Securing your route", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(tor.message, color = Muted, fontSize = 14.sp)
            if (tor.state == TorController.State.ERROR) {
                Spacer(Modifier.height(18.dp))
                Button(onClick = onReset) { Text("Turn Tor off and return to normal browsing") }
            }
        }
    }
}

@Composable
private fun LoadingPanel(message: String) {
    Box(Modifier.fillMaxSize().background(Night), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Security, contentDescription = null, tint = Accent, modifier = Modifier.size(38.dp))
            Spacer(Modifier.height(12.dp))
            Text(message, color = Muted, fontSize = 14.sp)
        }
    }
}

@Composable
private fun PanelHeader(title: String, subtitle: String, action: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        action?.invoke()
    }
}

@Composable
private fun EntryPanel(
    title: String,
    subtitle: String,
    entries: List<BrowserStore.Entry>,
    emptyTitle: String,
    emptyMessage: String,
    onOpen: (String) -> Unit,
    onRemove: ((String) -> Unit)?,
    onClear: (() -> Unit)? = null
) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PanelHeader(title, subtitle, action = if (onClear != null && entries.isNotEmpty()) {
            { TextButton(onClick = onClear) { Text("Clear") } }
        } else null)
        if (entries.isEmpty()) {
            EmptyState(emptyTitle, emptyMessage)
        } else {
            LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(entries, key = { it.url }) { entry ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 9.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).clickable { onOpen(entry.url) }.padding(vertical = 4.dp)) {
                                Text(entry.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(entry.url, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            if (onRemove != null) {
                                IconButton(onClick = { onRemove(entry.url) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Remove", tint = Muted)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, message: String) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 54.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Filled.BookmarkBorder, contentDescription = null, tint = Accent, modifier = Modifier.size(34.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.height(5.dp))
        Text(message, color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun AddonsPanel(
    shieldEnabled: Boolean,
    onShieldChange: (Boolean) -> Unit,
    onInstall: (String) -> Unit
) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PanelHeader("Add-ons & shields", "A small curated store · review permissions before installing")
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(19.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Shield, contentDescription = null, tint = Mint, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Tracking protection", fontWeight = FontWeight.SemiBold)
                        Text("Built into the GeckoView engine", color = Muted, fontSize = 12.sp)
                    }
                    Switch(checked = shieldEnabled, onCheckedChange = onShieldChange)
                }
            }
            AddonCard(
                name = "uBlock Origin",
                detail = "Community-maintained content blocker. The browser asks before granting extension permissions.",
                onInstall = { onInstall("https://addons.mozilla.org/firefox/downloads/latest/ublock-origin/latest.xpi") }
            )
            AddonCard(
                name = "Dark Reader",
                detail = "Optional page darkening extension from Mozilla Add-ons.",
                onInstall = { onInstall("https://addons.mozilla.org/firefox/downloads/latest/darkreader/latest.xpi") }
            )
            Text("Add-ons are fetched from Mozilla Add-ons and signature-checked by GeckoView. Only install extensions you trust.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 18.dp))
        }
    }
}

@Composable
private fun AddonCard(name: String, detail: String, onInstall: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(19.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Extension, contentDescription = null, tint = Accent)
                Spacer(Modifier.width(9.dp))
                Text(name, fontWeight = FontWeight.SemiBold)
            }
            Text(detail, color = Muted, fontSize = 12.sp)
            FilledTonalButton(onClick = onInstall) { Text("Review & install") }
        }
    }
}

@Composable
private fun VpnPanel() {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PanelHeader("VPN providers", "Provider choices are planned for a later release")
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(21.dp)) {
                Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Filled.VpnKey, contentDescription = null, tint = Accent, modifier = Modifier.size(28.dp))
                    Text("No VPN is connected", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("This first build does not operate VPN servers or tunnel traffic through a provider. We’ll add provider selection only after a real provider and its Android integration are chosen.", color = Muted, fontSize = 13.sp)
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Tor is separate", fontWeight = FontWeight.SemiBold)
                    Text("The Tor control above routes browser traffic through Tor; it is not a VPN and does not protect other apps on your device.", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun SettingsPanel(
    shieldEnabled: Boolean,
    onShieldChange: (Boolean) -> Unit,
    darkTheme: Boolean,
    onThemeChange: (Boolean) -> Unit,
    onClearHistory: () -> Unit,
    tor: TorController
) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PanelHeader("Settings", "Privacy and browser preferences")
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SettingToggle("Tracking protection", "GeckoView protection for known trackers", shieldEnabled, onShieldChange, Icons.Filled.Shield)
            SettingToggle("Dark appearance", "Use the dark browser theme", darkTheme, onThemeChange, Icons.Filled.Settings)
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Tor status", fontWeight = FontWeight.SemiBold)
                    Text(tor.message, color = Muted, fontSize = 12.sp)
                    Text("Onion addresses are blocked unless Tor has a ready route.", color = Muted, fontSize = 12.sp)
                }
            }
            FilledTonalButton(onClick = onClearHistory) { Icon(Icons.Filled.Delete, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Clear browsing history") }
            Text("Bookmarks and history are stored locally. Private tabs are not added to history.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 18.dp))
        }
    }
}

@Composable
private fun SettingToggle(title: String, detail: String, checked: Boolean, onChange: (Boolean) -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Accent)
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(detail, color = Muted, fontSize = 11.sp)
            }
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}

@Composable
private fun TabsPanel(
    tabs: List<BrowserTab>,
    activeTabId: Long,
    onSelect: (Long) -> Unit,
    onClose: (Long) -> Unit,
    onNewTab: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PanelHeader("Tabs", "${tabs.size} open", action = {
            IconButton(onClick = onNewTab) { Icon(Icons.Filled.Add, contentDescription = "New tab", tint = Accent) }
        })
        if (tabs.isEmpty()) EmptyState("No open tabs", "Create a tab to continue browsing.")
        else LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(tabs, key = { it.id }) { tab ->
                Card(
                    modifier = Modifier.clickable { onSelect(tab.id) },
                    colors = CardDefaults.cardColors(containerColor = if (tab.id == activeTabId) PanelRaised else Panel),
                    shape = RoundedCornerShape(17.dp),
                    border = if (tab.id == activeTabId) BorderStroke(1.dp, Accent.copy(alpha = 0.55f)) else null
                ) {
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (tab.privateMode) Icons.Filled.Lock else Icons.Filled.Home, contentDescription = null, tint = if (tab.privateMode) Accent else Muted)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (tab.isHome) "New tab" else tab.address, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                            Text(if (tab.privateMode) "Private tab" else "Normal tab", color = Muted, fontSize = 11.sp)
                        }
                        IconButton(onClick = { onClose(tab.id) }) { Icon(Icons.Filled.Close, contentDescription = "Close tab", tint = Muted) }
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuPanel(onSelect: (BrowserPage) -> Unit, onNewTab: () -> Unit, onPrivateTab: () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PanelHeader("Browser menu", "Tools and library")
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            MenuRow("New tab", "Start a regular browsing tab", Icons.Filled.Add, onNewTab)
            MenuRow("New private tab", "Does not save browsing history", Icons.Filled.Lock, onPrivateTab)
            MenuRow("History", "Recently visited pages", Icons.Filled.History) { onSelect(BrowserPage.HISTORY) }
            MenuRow("Downloads", "Saved files", Icons.Filled.Download) { onSelect(BrowserPage.DOWNLOADS) }
            MenuRow("Settings", "Privacy, appearance, and data", Icons.Filled.Settings) { onSelect(BrowserPage.SETTINGS) }
            MenuRow("Open tabs", "Switch or close tabs", Icons.Filled.GridView) { onSelect(BrowserPage.TABS) }
        }
    }
}

@Composable
private fun MenuRow(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
        Row(Modifier.padding(horizontal = 15.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Accent)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(detail, color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun DownloadsPanel() {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PanelHeader("Downloads", "Files saved from the web")
        EmptyState("No downloads yet", "The downloads screen is in the browser shell; safe file-transfer handling is the next implementation step.")
    }
}
