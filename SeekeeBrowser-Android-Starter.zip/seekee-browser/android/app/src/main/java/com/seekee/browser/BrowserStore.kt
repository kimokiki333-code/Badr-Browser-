package com.seekee.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small local-only store for the first browser iteration. Nothing is synced. */
class BrowserStore(context: Context) {
    private val prefs = context.getSharedPreferences("seekee_browser_v1", Context.MODE_PRIVATE)

    data class Entry(val title: String, val url: String, val savedAt: Long)

    fun bookmarks(): List<Entry> = readEntries(KEY_BOOKMARKS)

    fun history(): List<Entry> = readEntries(KEY_HISTORY)

    fun addBookmark(url: String, title: String = url) {
        if (url.isBlank()) return
        val items = bookmarks().toMutableList()
        if (items.none { it.url == url }) {
            items.add(0, Entry(title.ifBlank { url }, url, System.currentTimeMillis()))
            writeEntries(KEY_BOOKMARKS, items)
        }
    }

    fun removeBookmark(url: String) {
        writeEntries(KEY_BOOKMARKS, bookmarks().filterNot { it.url == url })
    }

    fun addVisit(url: String, title: String = url, privateMode: Boolean) {
        if (privateMode || url.isBlank() || url.startsWith("about:") || url.startsWith("file:")) return
        val items = history().filterNot { it.url == url }.toMutableList()
        items.add(0, Entry(title.ifBlank { url }, url, System.currentTimeMillis()))
        writeEntries(KEY_HISTORY, items.take(MAX_HISTORY))
    }

    fun clearHistory() = writeEntries(KEY_HISTORY, emptyList())

    private fun readEntries(key: String): List<Entry> {
        val raw = prefs.getString(key, "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val url = item.optString("url").trim()
                    if (url.isNotEmpty()) {
                        add(
                            Entry(
                                title = item.optString("title", url),
                                url = url,
                                savedAt = item.optLong("savedAt", 0L)
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun writeEntries(key: String, entries: List<Entry>) {
        val array = JSONArray()
        entries.forEach { entry ->
            array.put(
                JSONObject()
                    .put("title", entry.title)
                    .put("url", entry.url)
                    .put("savedAt", entry.savedAt)
            )
        }
        prefs.edit().putString(key, array.toString()).apply()
    }

    private companion object {
        const val KEY_BOOKMARKS = "bookmarks"
        const val KEY_HISTORY = "history"
        const val MAX_HISTORY = 500
    }
}
