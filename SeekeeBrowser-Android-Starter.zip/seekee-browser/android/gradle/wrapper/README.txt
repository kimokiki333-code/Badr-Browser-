The Gradle 8.13 wrapper JAR, Unix launcher, Windows launcher, and distribution properties are included. Android Studio is the recommended build environment for this project.
