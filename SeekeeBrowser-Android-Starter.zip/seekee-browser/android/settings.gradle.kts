pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven(url = "https://maven.mozilla.org/maven2/")
        maven(url = "https://raw.githubusercontent.com/guardianproject/gpmaven/master/")
    }
}

rootProject.name = "SeekeeBrowser"
include(":app")
