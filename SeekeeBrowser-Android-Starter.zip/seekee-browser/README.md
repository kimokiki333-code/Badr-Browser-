# Seekee Browser — Android starter

A clean Android browser project started from the requested direction: **a regular everyday browser with Tor/onion access and a built-in add-on store**. The existing Drive items were not used as source code; this is a new project.

## What is here

- `browser-preview.html` — an interactive, offline UI preview. It deliberately makes no network requests and does not pretend Tor, VPN, or extension installs are active.
- `android/` — Android Studio project source using GeckoView as the browser engine and an embedded Tor service as the planned browser-only Tor route.
- `docs/architecture.md` — scope, privacy behaviour, and the next implementation/test milestones.

### Wired in the Android source

- Address/search bar, back/forward/reload, tabs, normal and private sessions
- Local-only bookmarks and normal-tab history
- GeckoView tracking protection toggle
- Add-on install entries for uBlock Origin and Dark Reader, with an in-app permission prompt
- Embedded Tor startup state and SOCKS proxy preferences; `.onion` navigation is blocked unless Tor is reported ready
- Fail-closed behavior on Tor errors (the code does not intentionally fall back to a direct connection)
- VPN provider screen is explicitly marked **not connected / later release**

### Not finished / not verified

- **No APK was built or run here.** This workspace has Java 11 but no Android SDK or `adb`; Android Studio/JDK 17+ and Android SDK 36 are needed to build and test it.
- Downloads are a UI placeholder; secure browser-managed download handling remains to be implemented.
- The add-on screens and Tor route need an on-device integration test before this should be used for sensitive browsing. Do not treat this starter as an audited privacy product.
- VPN is intentionally not implemented: it needs a selected provider and its supported Android integration, or an operator/server service. Tor is not a VPN.

## Build in Android Studio

1. Install Android Studio with **JDK 17 or newer** and Android SDK platform 36.
2. Open the `android/` folder.
3. Let Gradle sync, then run the `app` configuration on a physical Android device.
4. Before using Tor or extensions, test navigation, proxy status, DNS behavior, route failure, app restart, private-tab behavior, and permissions on-device.

The project pins GeckoView `160.0.20261104181552` and Guardian Project `tor-android` `0.4.9.13.2`. The GeckoView AAR was checked against Mozilla's Maven metadata; Guardian's Tor AAR/POM are served from its Maven repository. GeckoView exposes browser and WebExtension APIs in its Android library [documentation](https://mozilla.github.io/geckoview/javadoc/mozilla-central/index.html); Guardian Project documents its embedded Tor service and Android integration in the [tor-android repository](https://github.com/guardianproject/tor-android).
