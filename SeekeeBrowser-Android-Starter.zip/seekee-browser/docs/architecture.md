# Architecture and release checklist

## Product direction

Seekee Browser should feel like a normal mobile browser first: address/search, tabs, history, bookmarks, private tabs, downloads, settings, shields, and an extension store. Tor is an explicit optional browser route for onion and clearnet pages. VPN provider selection is deferred as requested.

## Current source layout

- **GeckoView** renders pages and hosts browser sessions. Normal and private tabs use separate session settings.
- **BrowserStore** persists bookmarks and normal-tab history locally with SharedPreferences. Private tabs are not recorded.
- **TorController** binds to Guardian Project's Tor service, waits for the service's ready status, reads its SOCKS port, and asks Gecko to use SOCKS5 with remote DNS. `.onion` navigation is rejected until Tor is ready.
- **Gecko preference routing** disables direct fallback and WebRTC in Tor mode. If Tor setup fails, the browser attempts to leave a dead local proxy in place rather than silently routing direct.
- **Add-ons** use GeckoView's signed WebExtension installation flow and prompt for requested permissions. The first catalog is deliberately small.
- **VPN** is only a later-version information screen. No provider is selected and no VPN connection is started.

## Safety rules for the next pass

1. Keep navigation disabled while changing route modes; close the current sessions before switching the runtime proxy.
2. Test that `.onion` names are resolved remotely through Tor and never queried over the normal DNS path.
3. Test Tor startup failure, abrupt Tor service death, losing Wi-Fi, force-stop/relaunch, and clearing Tor mode. Any uncertain route should block, not go direct.
4. Verify all browser-engine requests, extension installs, media, and downloads follow the selected route. Do not use a second HTTP stack for page content.
5. Treat extension permissions as user consent; do not grant private-mode access by default.
6. Audit the exact GeckoView and Tor library binaries before release; keep their versions pinned and update promptly for security releases.
7. Only design VPN integration after choosing a provider and confirming whether it uses a supported Android VPN SDK/API or external app handoff. Do not label Tor as VPN.

## Known gap

The downloads panel is a placeholder. Downloads need to be captured and saved through a route-aware GeckoView flow, especially when Tor is active. It should not use Android DownloadManager by blindly re-fetching a URL, since that can lose cookies or bypass the selected route.
