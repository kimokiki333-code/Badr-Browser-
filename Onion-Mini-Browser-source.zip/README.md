# Onion Mini Browser

A compact Android browser prototype styled around the supplied Brave/Tor-style menu. It uses Mozilla GeckoView for web pages and Guardian Project's Android Tor service for a local Tor SOCKS proxy.

## Included

- Address/search bar using DuckDuckGo for searches
- Back, forward, reload/stop, home/start page, bookmarks and tab counter
- Multiple tabs and non-persistent private tabs
- Tor routing toggle, bootstrap progress, a Tor-only route check and a `NEWNYM` circuit request
- Optional obfs4 bridge support for networks that block direct Tor connections; bridge lines are stored locally
- `.onion` address support through SOCKS5 with remote DNS enabled
- History and bookmarks stored locally
- Find-in-page, desktop/mobile user-agent toggle and text scaling
- Copy/share link, open in another app and pin page to the home screen
- Downloads saved in the app's private Downloads folder
- Site-data clearing, page information, source view and a small browser-event console
- Dark UI inspired by the attached screenshot

## Install the APK

`artifacts/Onion-Mini-Browser-arm64-debug.apk` is version **1.1.0**, a **debug-signed APK** for **arm64-v8a** phones/tablets running **Android 8.0 (API 26) or newer**. It is about 105 MB because it bundles GeckoView, Tor and the optional obfs4 transport. It is not a Play Store release and uses the standard Gradle debug signing key.

Transfer it to the phone, allow installation from that source if Android asks, and install it. The equivalent ADB command is:

```sh
adb install -r artifacts/Onion-Mini-Browser-arm64-debug.apk
```

## Build from source

Requirements used for this build:

- JDK 24
- Android SDK Platform 37.2 and Build Tools 37
- Gradle 9.9.1 (downloaded by the included wrapper)
- Android Gradle Plugin 9.5.1

Then run:

```sh
./gradlew assembleDebug
```

The result is written to `app/build/outputs/apk/debug/app-debug.apk`.

## Important privacy notes

- Tor routing is on by default. On first launch, wait for **Tor connected** before browsing. GeckoView is set to SOCKS5 with remote DNS, an empty proxy-bypass list, and direct-failover/bypass preferences disabled; an unavailable Tor endpoint should fail closed. This routes Onion Mini's browser traffic only; it is **not** a device-wide Android VPN.
- If direct Tor bootstrap is blocked, open **Privacy → Tor bridges** and paste complete obfs4 bridge lines from the Tor Project or another source you trust. Bridge support is opt-in; no bridge list is embedded. The bundled obfs4 transport is used only when bridge lines are configured.
- **Test Tor connection** makes a SOCKS5 request through the local Tor port, sends the hostname inside the SOCKS request (no local DNS lookup), and asks the Tor Project check endpoint whether the exit is Tor. It never falls back to a direct internet request. This checks Tor reachability from the app process, but does not by itself prove GeckoView page loads are using the proxy.
- Turning Tor off requires confirmation; websites can then see the ordinary network IP address.
- Onion Mini is an **independent prototype, not the official Tor Browser** and is not affiliated with the Tor Project. A Tor proxy alone does not provide all Tor Browser protections, such as its complete anti-fingerprinting and security-hardening behavior. Do not treat this app as a guarantee of anonymity.
- The developer console in this prototype records browser/Tor navigation events; it is not a full JavaScript console or remote DevTools suite.
- Downloads are stored in app-private storage and are removed if the app is uninstalled.
- This APK was compiled and signature-verified in the build environment, but it was **not exercised on a physical Android device or emulator here**. Test Tor bootstrap, DNS/onion access, navigation and downloads on the target phone before relying on it.

## Dependencies

- [Mozilla GeckoView](https://mozilla.github.io/geckoview/)
- [Guardian Project tor-android](https://github.com/guardianproject/tor-android)
- [Briar Project obfs4proxy-android 0.0.14-tor2](https://central.sonatype.com/artifact/org.briarproject/obfs4proxy-android/0.0.14-tor2) for optional bridges (BSD-3-Clause; license text in `third_party/obfs4proxy/LICENSE`)
- AndroidX Core and LocalBroadcastManager

Consult each dependency's upstream license and notices when redistributing the app.
