package com.onionmini.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import net.freehaven.tor.control.TorControlConnection;

import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.ContentBlocking;
import org.mozilla.geckoview.GeckoPreferenceController;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.StorageController;
import org.mozilla.geckoview.WebResponse;
import org.torproject.jni.TorService;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URLDecoder;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Compact privacy browser prototype. GeckoView handles page rendering; Guardian Project's
 * Tor Android service provides the local SOCKS endpoint. Tor is fail-closed while enabled.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "browser_settings";
    private static final String PREF_TOR = "tor_enabled";
    private static final String PREF_TOR_BRIDGES = "tor_obfs4_bridges";
    private static final String PREF_FONT = "font_factor";
    private static final String HOME_URL = "file:///android_asset/start.html";
    private static final String SEARCH_URL = "https://duckduckgo.com/?q=";

    private static final int BG = Color.rgb(11, 12, 16);
    private static final int SURFACE = Color.rgb(25, 26, 32);
    private static final int CARD = Color.rgb(37, 38, 45);
    private static final int CARD_HI = Color.rgb(48, 49, 57);
    private static final int ACCENT = Color.rgb(64, 226, 208);
    private static final int PURPLE = Color.rgb(171, 118, 255);
    private static final int TEXT = Color.rgb(244, 245, 248);
    private static final int MUTED = Color.rgb(161, 165, 177);
    private static final int RED = Color.rgb(255, 93, 116);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService downloadWorker = Executors.newSingleThreadExecutor();
    private final ExecutorService torMonitorWorker = Executors.newSingleThreadExecutor();
    private final ExecutorService torTestWorker = Executors.newSingleThreadExecutor();
    private final ArrayDeque<String> eventLog = new ArrayDeque<>();
    private final ArrayList<BrowserTab> tabs = new ArrayList<>();
    private SharedPreferences preferences;
    private BrowserStore store;

    private LinearLayout root;
    private LinearLayout addressShell;
    private EditText addressField;
    private TextView routeText;
    private TextView onionMark;
    private TextView tabButton;
    private TextView bookmarkButton;
    private View progressBar;
    private FrameLayout pageHost;
    private GeckoView geckoView;
    private TextView placeholderStatus;
    private TextView placeholderTitle;
    private TextView placeholderAction;

    private GeckoRuntime runtime;
    private boolean engineReady = false;
    private boolean torEnabled;
    private boolean torReady = false;
    private boolean torServiceBound = false;
    private boolean torServiceStarted = false;
    private boolean torReceiverRegistered = false;
    private boolean desktopMode = false;
    private boolean javascriptEnabled = true;
    private boolean pageLoading = false;
    private int torPort = -1;
    private boolean torStatusQueryPending = false;
    private boolean torBootstrapHintShown = false;
    private long torStartElapsedRealtime;
    private String lastTorBootstrapInfo = "";
    private String torError;
    private float fontFactor = 1.0f;
    private String queuedStartUrl;
    private TorService torService;
    private BrowserTab activeTab;
    private Dialog openMenuDialog;

    private final Runnable torBootstrapPoll = new Runnable() {
        @Override
        public void run() {
            if (isFinishing() || !torEnabled || torReady) return;
            TorService service = torService;
            if (service != null && !torStatusQueryPending) {
                torStatusQueryPending = true;
                torMonitorWorker.execute(() -> {
                    String info = null;
                    try { info = service.getInfo("status/bootstrap-phase"); }
                    catch (Exception ignored) { }
                    final String phase = info;
                    mainHandler.post(() -> {
                        torStatusQueryPending = false;
                        if (torEnabled && !torReady && service == torService && !TextUtils.isEmpty(phase)) updateTorBootstrapProgress(phase);
                    });
                });
            }
            if (torEnabled && !torReady) mainHandler.postDelayed(this, 2500);
        }
    };

    private final BroadcastReceiver torReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            String action = intent.getAction();
            if (TorService.ACTION_ERROR.equals(action)) {
                String detail = intent.getStringExtra(Intent.EXTRA_TEXT);
                torError = TextUtils.isEmpty(detail) ? "Tor reported a startup error." : detail;
                logEvent("Tor error: " + torError);
                showTorProblem(torError);
                return;
            }
            if (!TorService.ACTION_STATUS.equals(action)) return;
            String state = intent.getStringExtra(TorService.EXTRA_STATUS);
            logEvent("Tor status: " + (state == null ? "unknown" : state));
            if (TorService.STATUS_ON.equals(state)) {
                torReady = true;
                torError = null;
                mainHandler.removeCallbacks(torBootstrapPoll);
                if (torService != null) torPort = torService.getSocksPort();
                if (torPort <= 0) torPort = TorService.socksPort;
                updatePrivacyUi();
                if (torPort > 0) {
                    logEvent("Tor circuit established; SOCKS port " + torPort + ".");
                    if (!engineReady) createEngine(true, torPort);
                    else configureProxy(true, torPort, true);
                } else {
                    mainHandler.postDelayed(MainActivity.this::retryTorPort, 700);
                }
            } else if (TorService.STATUS_STARTING.equals(state)) {
                torReady = false;
                updatePrivacyUi();
                mainHandler.removeCallbacks(torBootstrapPoll);
                mainHandler.postDelayed(torBootstrapPoll, 1200);
            } else if (TorService.STATUS_OFF.equals(state) || TorService.STATUS_STOPPING.equals(state)) {
                torReady = false;
                mainHandler.removeCallbacks(torBootstrapPoll);
                updatePrivacyUi();
                if (torEnabled && !engineReady) showTorProblem(torError == null
                        ? "Tor stopped before a circuit was ready." : torError);
            }
        }
    };

    private final ServiceConnection torConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            TorService.LocalBinder localBinder = (TorService.LocalBinder) binder;
            torService = localBinder.getService();
            torServiceBound = true;
            int port = torService.getSocksPort();
            if (port > 0) torPort = port;
            logEvent("Connected to embedded Tor service.");
            if (torReady && torPort > 0) {
                if (!engineReady) createEngine(true, torPort);
                else configureProxy(true, torPort, true);
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            torService = null;
            torServiceBound = false;
            torReady = false;
            torPort = -1;
            mainHandler.removeCallbacks(torBootstrapPoll);
            updatePrivacyUi();
            logEvent("Tor service disconnected.");
            if (torEnabled) {
                for (BrowserTab tab : tabs) {
                    try { tab.session.stop(); } catch (Exception ignored) { }
                }
                if (runtime != null) configureProxy(true, 1, false);
                showTorProblem("The Tor service disconnected. Traffic remains blocked until Tor reconnects.");
            }
        }
    };

    private static final class BrowserTab {
        final GeckoSession session;
        final boolean privateTab;
        String url = HOME_URL;
        String title = "New tab";
        boolean canGoBack;
        boolean canGoForward;
        boolean desktop;

        BrowserTab(GeckoSession session, boolean privateTab) {
            this.session = session;
            this.privateTab = privateTab;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        store = new BrowserStore(this);
        fontFactor = preferences.getFloat(PREF_FONT, 1.0f);
        torEnabled = preferences.getBoolean(PREF_TOR, true);
        queuedStartUrl = getIntent() != null && getIntent().getData() != null
                ? getIntent().getData().toString() : HOME_URL;

        buildBrowserUi();
        updatePrivacyUi();
        logEvent("Onion Mini opened.");

        if (torEnabled) {
            startTorService();
        } else {
            createEngine(false, -1);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getData() != null) {
            String link = intent.getData().toString();
            if (engineReady) openInCurrentTab(link);
            else queuedStartUrl = link;
        }
    }

    private void buildBrowserUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);

        buildAddressBar();
        progressBar = new View(this);
        progressBar.setBackgroundColor(ACCENT);
        progressBar.setVisibility(View.GONE);
        root.addView(progressBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)));

        pageHost = new FrameLayout(this);
        pageHost.setBackgroundColor(BG);
        root.addView(pageHost, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        showPlaceholder("Starting the privacy engine", "Preparing a private browser session…", false);

        buildBottomBar();
    }

    private void buildAddressBar() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.HORIZONTAL);
        outer.setGravity(Gravity.CENTER_VERTICAL);
        outer.setPadding(dp(14), dp(10), dp(12), dp(8));
        outer.setBackgroundColor(BG);

        addressShell = new LinearLayout(this);
        addressShell.setOrientation(LinearLayout.HORIZONTAL);
        addressShell.setGravity(Gravity.CENTER_VERTICAL);
        addressShell.setPadding(dp(12), dp(6), dp(12), dp(6));
        addressShell.setBackground(rounded(CARD, 32));

        onionMark = new TextView(this);
        onionMark.setText("◉");
        onionMark.setTextSize(25);
        onionMark.setTextColor(PURPLE);
        onionMark.setGravity(Gravity.CENTER);
        onionMark.setContentDescription("Tor routing status");
        addressShell.addView(onionMark, new LinearLayout.LayoutParams(dp(34), dp(42)));

        LinearLayout entryColumn = new LinearLayout(this);
        entryColumn.setOrientation(LinearLayout.VERTICAL);
        entryColumn.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams entryColumnLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        entryColumnLp.leftMargin = dp(8);
        addressShell.addView(entryColumn, entryColumnLp);

        addressField = new EditText(this);
        addressField.setSingleLine(true);
        addressField.setTextColor(TEXT);
        addressField.setHintTextColor(MUTED);
        addressField.setHint("Search or enter address");
        addressField.setTextSize(16);
        addressField.setSelectAllOnFocus(true);
        addressField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addressField.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressField.setPadding(0, 0, 0, 0);
        addressField.setBackgroundColor(Color.TRANSPARENT);
        addressField.setOnEditorActionListener((view, actionId, event) -> {
            boolean enter = actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN);
            if (enter) {
                navigateFromAddressBar();
                return true;
            }
            return false;
        });
        addressField.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus && activeTab != null && activeTab.url != null && !HOME_URL.equals(activeTab.url)) {
                String raw = activeTab.url.startsWith("view-source:") ? activeTab.url.substring(12) : activeTab.url;
                addressField.setText(raw);
                addressField.selectAll();
            }
        });
        entryColumn.addView(addressField, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));

        routeText = new TextView(this);
        routeText.setTextSize(11);
        routeText.setTextColor(ACCENT);
        routeText.setSingleLine(true);
        routeText.setText("Starting onion routing…");
        entryColumn.addView(routeText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(18)));

        addressShell.setOnClickListener(v -> {
            if (addressField != null) {
                addressField.requestFocus();
                addressField.selectAll();
                ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(addressField, InputMethodManager.SHOW_IMPLICIT);
            }
        });
        outer.addView(addressShell, new LinearLayout.LayoutParams(0, dp(64), 1f));

        TextView overflow = iconButton("⋮", "Open browser menu", 25);
        LinearLayout.LayoutParams overflowLp = new LinearLayout.LayoutParams(dp(42), dp(54));
        overflowLp.leftMargin = dp(4);
        outer.addView(overflow, overflowLp);
        overflow.setOnClickListener(v -> showBrowserMenu());
        root.addView(outer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void buildBottomBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setBackgroundColor(SURFACE);
        bar.setPadding(dp(4), dp(3), dp(4), dp(4));
        bar.setElevation(dp(8));

        addNavItem(bar, "‹", "Back", () -> goBack());
        addNavItem(bar, "›", "Forward", () -> goForward());
        addNavItem(bar, "⟳", "Reload", () -> reloadCurrent());
        bookmarkButton = addNavItem(bar, "☆", "Bookmark", () -> toggleBookmark());
        tabButton = addNavItem(bar, "▢", "Tabs", () -> showTabs());
        addNavItem(bar, "☰", "Menu", () -> showBrowserMenu());

        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
    }

    private TextView addNavItem(LinearLayout bar, String icon, String label, Runnable action) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setBackground(selectableBackground());
        TextView glyph = new TextView(this);
        glyph.setText(icon);
        glyph.setTextColor(TEXT);
        glyph.setTextSize(22);
        glyph.setGravity(Gravity.CENTER);
        item.addView(glyph, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));
        TextView caption = new TextView(this);
        caption.setText(label);
        caption.setTextColor(MUTED);
        caption.setTextSize(9);
        caption.setGravity(Gravity.CENTER);
        item.addView(caption, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(16)));
        item.setOnClickListener(v -> action.run());
        bar.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        return glyph;
    }

    private TextView iconButton(String icon, String description, int size) {
        TextView v = new TextView(this);
        v.setText(icon);
        v.setTextColor(TEXT);
        v.setTextSize(size);
        v.setGravity(Gravity.CENTER);
        v.setContentDescription(description);
        v.setBackground(selectableBackground());
        return v;
    }

    private void showPlaceholder(String title, String message, boolean canRetry) {
        if (pageHost == null) return;
        pageHost.removeAllViews();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(28), dp(30), dp(28), dp(30));

        TextView logo = new TextView(this);
        logo.setText("◉");
        logo.setTextColor(PURPLE);
        logo.setTextSize(58);
        logo.setGravity(Gravity.CENTER);
        box.addView(logo, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(74)));

        TextView brand = makeText("ONION MINI", 12, ACCENT, true);
        brand.setLetterSpacing(0.18f);
        brand.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28));
        brandLp.bottomMargin = dp(10);
        box.addView(brand, brandLp);

        placeholderTitle = makeText(title, 22, TEXT, true);
        placeholderTitle.setGravity(Gravity.CENTER);
        box.addView(placeholderTitle, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        placeholderStatus = makeText(message, 14, MUTED, false);
        placeholderStatus.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.topMargin = dp(10);
        box.addView(placeholderStatus, statusLp);

        TextView safety = makeText("Traffic can be routed through Tor, but this compact app is not the official Tor Browser and does not include every Tor Browser anti-fingerprinting defense.", 12, MUTED, false);
        safety.setGravity(Gravity.CENTER);
        safety.setPadding(dp(14), dp(16), dp(14), dp(12));
        box.addView(safety, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        placeholderAction = makeText(canRetry ? "RETRY TOR" : "", 13, ACCENT, true);
        placeholderAction.setGravity(Gravity.CENTER);
        placeholderAction.setPadding(dp(20), dp(10), dp(20), dp(10));
        placeholderAction.setBackground(rounded(SURFACE, 18));
        if (canRetry) {
            LinearLayout.LayoutParams retryLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            retryLp.topMargin = dp(10);
            box.addView(placeholderAction, retryLp);
            placeholderAction.setOnClickListener(v -> startTorService());
        }
        pageHost.addView(box, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void showTorProblem(String message) {
        mainHandler.post(() -> {
            updatePrivacyUi();
            if (!engineReady || torEnabled) {
                showPlaceholder("Tor is not ready", message + " No page has been opened outside Tor.", true);
            }
            toast(message);
        });
    }

    private void updateTorBootstrapProgress(String info) {
        String progress = extractTorValue(info, "PROGRESS=");
        String summary = extractTorValue(info, "SUMMARY=");
        String step = TextUtils.isEmpty(progress) ? "Tor is negotiating its first circuit" : "Tor bootstrap " + progress + "%";
        if (!TextUtils.isEmpty(summary)) step += " · " + summary;
        if (!info.equals(lastTorBootstrapInfo)) {
            lastTorBootstrapInfo = info;
            logEvent(step);
        }

        boolean longWait = torStartElapsedRealtime > 0
                && SystemClock.elapsedRealtime() - torStartElapsedRealtime > 120_000;
        if (longWait && !torBootstrapHintShown) {
            torBootstrapHintShown = true;
            logEvent("Tor is still bootstrapping. If this network blocks Tor, add an obfs4 bridge in Privacy > Tor bridges.");
        }
        if (placeholderStatus != null && !engineReady) {
            String text = step + "\nDirect fallback remains blocked.";
            if (longWait) text += "\nIf it stays stuck, add an obfs4 bridge from Privacy > Tor bridges.";
            placeholderStatus.setText(text);
        }
    }

    private String extractTorValue(String info, String key) {
        if (TextUtils.isEmpty(info)) return null;
        int start = info.indexOf(key);
        if (start < 0) return null;
        start += key.length();
        if (start >= info.length()) return null;
        if (info.charAt(start) == '\"') {
            int end = info.indexOf('\"', start + 1);
            return end > start ? info.substring(start + 1, end) : null;
        }
        int end = info.indexOf(' ', start);
        return info.substring(start, end < 0 ? info.length() : end);
    }

    private void retryTorPort() {
        if (!torEnabled || !torReady || isFinishing()) return;
        if (torService != null) torPort = torService.getSocksPort();
        if (torPort <= 0) torPort = TorService.socksPort;
        if (torPort > 0) {
            if (!engineReady) createEngine(true, torPort);
            else configureProxy(true, torPort, true);
        } else {
            mainHandler.postDelayed(this::retryTorPort, 700);
        }
    }

    private String normalizeObfs4BridgeLines(String raw) {
        if (TextUtils.isEmpty(raw) || raw.trim().isEmpty()) return "";
        if (raw.length() > 4096) throw new IllegalArgumentException("Bridge text is too long (maximum 4 KB).");
        StringBuilder normalized = new StringBuilder();
        int count = 0;
        for (String original : raw.split("\\r?\\n")) {
            String line = original.trim();
            if (line.isEmpty()) continue;
            if (line.regionMatches(true, 0, "Bridge ", 0, 7)) line = line.substring(7).trim();
            String[] parts = line.split("\\s+");
            if (parts.length < 5 || parts.length > 12 || !"obfs4".equalsIgnoreCase(parts[0])) {
                throw new IllegalArgumentException("Use full obfs4 bridge lines only (one per line).");
            }
            String endpoint = parts[1];
            int colon = endpoint.lastIndexOf(':');
            if (colon < 1 || colon == endpoint.length() - 1) throw new IllegalArgumentException("A bridge line has an invalid address or port.");
            String host = endpoint.substring(0, colon);
            if (host.startsWith("[") && host.endsWith("]")) host = host.substring(1, host.length() - 1);
            if (host.isEmpty()) throw new IllegalArgumentException("A bridge line has an invalid address.");
            for (int i = 0; i < host.length(); i++) {
                char c = host.charAt(i);
                if (!(Character.isDigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F') || c == '.' || c == ':' || c == '-')) {
                    throw new IllegalArgumentException("Bridge addresses must be numeric IP addresses.");
                }
            }
            int port;
            try { port = Integer.parseInt(endpoint.substring(colon + 1)); }
            catch (NumberFormatException ex) { throw new IllegalArgumentException("A bridge line has an invalid port."); }
            if (port < 1 || port > 65535) throw new IllegalArgumentException("A bridge port must be between 1 and 65535.");
            if (parts[2].length() != 40) throw new IllegalArgumentException("A bridge line needs its 40-character fingerprint.");
            for (int i = 0; i < parts[2].length(); i++) {
                char c = parts[2].charAt(i);
                if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'))) {
                    throw new IllegalArgumentException("The obfs4 fingerprint must be 40 hexadecimal characters.");
                }
            }
            boolean hasCert = false;
            boolean hasIatMode = false;
            for (int i = 3; i < parts.length; i++) {
                String token = parts[i];
                for (int j = 0; j < token.length(); j++) {
                    char c = token.charAt(j);
                    if (!(Character.isLetterOrDigit(c) || c == '.' || c == ':' || c == '-' || c == '_' || c == '=' || c == '/' || c == '+' || c == '[' || c == ']')) {
                        throw new IllegalArgumentException("The bridge line contains unsupported characters.");
                    }
                }
                if (token.startsWith("cert=") && token.length() > 5) hasCert = true;
                if (token.startsWith("iat-mode=")) hasIatMode = true;
            }
            if (!hasCert || !hasIatMode) throw new IllegalArgumentException("Paste the complete obfs4 line, including cert= and iat-mode=.");
            if (count++ >= 10) throw new IllegalArgumentException("You can add up to 10 bridges.");
            if (normalized.length() > 0) normalized.append('\n');
            normalized.append("obfs4 ");
            for (int i = 1; i < parts.length; i++) {
                if (i > 1) normalized.append(' ');
                normalized.append(parts[i]);
            }
        }
        return normalized.toString();
    }

    private void prepareTorConfiguration() throws IOException {
        String bridges = normalizeObfs4BridgeLines(preferences.getString(PREF_TOR_BRIDGES, ""));
        File torrc = TorService.getTorrc(this);
        if (bridges.isEmpty()) {
            if (torrc.exists() && !torrc.delete()) throw new IOException("Could not clear the previous bridge configuration.");
            return;
        }
        File obfs4 = new File(getApplicationInfo().nativeLibraryDir, "libobfs4proxy.so");
        if (!obfs4.isFile()) throw new IOException("The bundled obfs4 transport is missing; reinstall this APK.");
        StringBuilder config = new StringBuilder();
        config.append("UseBridges 1\n");
        config.append("ClientTransportPlugin obfs4 exec ").append(obfs4.getAbsolutePath()).append('\n');
        for (String line : bridges.split("\\n")) config.append("Bridge ").append(line).append('\n');
        File parent = torrc.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Could not create Tor's private configuration folder.");
        try (FileOutputStream output = new FileOutputStream(torrc, false)) {
            output.write(config.toString().getBytes(StandardCharsets.UTF_8));
        }
    }

    private void startTorService() {
        torEnabled = true;
        torReady = false;
        torError = null;
        torPort = -1;
        torStatusQueryPending = false;
        torBootstrapHintShown = false;
        lastTorBootstrapInfo = "";
        torStartElapsedRealtime = SystemClock.elapsedRealtime();
        mainHandler.removeCallbacks(torBootstrapPoll);
        preferences.edit().putBoolean(PREF_TOR, true).apply();
        updatePrivacyUi();
        logEvent("Starting embedded Tor.");
        showPlaceholder("Connecting to Tor", "Waiting for a Tor circuit. The browser will not fall back to a direct connection.", false);

        try {
            prepareTorConfiguration();
            if (!torReceiverRegistered) {
                IntentFilterCompat.registerTorReceiver(this, torReceiver);
                torReceiverRegistered = true;
            }
            Intent serviceIntent = new Intent(this, TorService.class);
            serviceIntent.setAction(TorService.ACTION_START);
            if (!torServiceStarted) {
                startService(serviceIntent);
                torServiceStarted = true;
            }
            if (!torServiceBound) {
                torServiceBound = bindService(new Intent(this, TorService.class), torConnection, Context.BIND_AUTO_CREATE);
            }
            mainHandler.postDelayed(torBootstrapPoll, 1500);
        } catch (Exception ex) {
            logEvent("Could not start Tor: " + ex.getMessage());
            torError = ex.getMessage();
            showTorProblem("Could not start the Tor service: " + ex.getMessage());
        }
    }

    private void stopTorService() {
        torReady = false;
        mainHandler.removeCallbacks(torBootstrapPoll);
        torStatusQueryPending = false;
        if (torServiceBound) {
            try { unbindService(torConnection); } catch (Exception ignored) { }
            torServiceBound = false;
            torService = null;
        }
        if (torServiceStarted) {
            try { stopService(new Intent(this, TorService.class)); } catch (Exception ignored) { }
            torServiceStarted = false;
        }
        if (torReceiverRegistered) {
            try { unregisterReceiver(torReceiver); } catch (Exception ignored) { }
            torReceiverRegistered = false;
        }
        updatePrivacyUi();
    }

    private void createEngine(boolean useTor, int port) {
        if (engineReady || runtime != null) return;
        showPlaceholder(useTor ? "Connecting to Tor" : "Starting browser", "Setting up the browser engine…", false);
        ContentBlocking.Settings contentBlocking = new ContentBlocking.Settings.Builder()
                .antiTracking(ContentBlocking.AntiTracking.DEFAULT)
                .build();
        GeckoRuntimeSettings.Builder runtimeBuilder = new GeckoRuntimeSettings.Builder()
                .contentBlocking(contentBlocking)
                .fontSizeFactor(fontFactor)
                .consoleOutput(true)
                .aboutConfigEnabled(false);
        if (useTor) {
            int startupPort = port > 0 ? port : 1;
            runtimeBuilder.arguments(new String[]{
                    "-setpref", "network.proxy.type=1",
                    "-setpref", "network.proxy.socks=127.0.0.1",
                    "-setpref", "network.proxy.socks_port=" + startupPort,
                    "-setpref", "network.proxy.socks_version=5",
                    "-setpref", "network.proxy.socks_remote_dns=true",
                    "-setpref", "network.proxy.no_proxies_on=",
                    "-setpref", "network.proxy.failover_direct=false",
                    "-setpref", "network.proxy.allow_bypass=false"
            });
        }
        GeckoRuntimeSettings settings = runtimeBuilder.build();
        try {
            runtime = GeckoRuntime.create(this, settings);
            configureProxy(useTor, port, false);
        } catch (Throwable error) {
            logEvent("Gecko startup failed: " + error.getMessage());
            showPlaceholder("Browser engine could not start", String.valueOf(error.getMessage()), false);
            toast("Browser engine could not start");
        }
    }

    /**
     * SOCKS5, remote DNS and the empty bypass list are set together. Gecko's direct failover and
     * proxy-bypass preferences are also disabled; while Tor is on, an unavailable endpoint is a dead-end.
     */
    private void configureProxy(boolean useTor, int port, boolean reloadAfter) {
        if (runtime == null) return;
        int safePort = useTor ? (port > 0 ? port : 1) : 0;
        int branch = GeckoPreferenceController.PREF_BRANCH_USER;
        List<GeckoPreferenceController.SetGeckoPreference<?>> settings = Arrays.asList(
                GeckoPreferenceController.SetGeckoPreference.setStringPref("network.proxy.socks", "127.0.0.1", branch),
                GeckoPreferenceController.SetGeckoPreference.setIntPref("network.proxy.socks_port", safePort, branch),
                GeckoPreferenceController.SetGeckoPreference.setIntPref("network.proxy.socks_version", 5, branch),
                GeckoPreferenceController.SetGeckoPreference.setBoolPref("network.proxy.socks_remote_dns", useTor, branch),
                GeckoPreferenceController.SetGeckoPreference.setStringPref("network.proxy.no_proxies_on", "", branch),
                GeckoPreferenceController.SetGeckoPreference.setBoolPref("network.proxy.failover_direct", false, branch),
                GeckoPreferenceController.SetGeckoPreference.setBoolPref("network.proxy.allow_bypass", false, branch),
                GeckoPreferenceController.SetGeckoPreference.setIntPref("network.proxy.type", useTor ? 1 : 0, branch)
        );
        GeckoPreferenceController.setGeckoPrefs(settings).accept(values -> mainHandler.post(() -> {
            if (!useTor || torReady) {
                if (!engineReady) {
                    engineReady = true;
                    createFirstTab(queuedStartUrl == null ? HOME_URL : queuedStartUrl);
                    logEvent(useTor ? "Browser connected to Tor SOCKS5." : "Browser started in direct mode.");
                } else {
                    showBrowserView();
                    if (reloadAfter && activeTab != null && !TextUtils.isEmpty(activeTab.url)) {
                        activeTab.session.loadUri(activeTab.url);
                    }
                }
                updatePrivacyUi();
            }
        }), error -> mainHandler.post(() -> {
            logEvent("Proxy setup failed: " + error.getMessage());
            showPlaceholder("Privacy settings failed", "The browser could not safely configure its network route. No page was opened.", false);
            toast("Could not configure the browser's network route");
        }));
    }

    private void createFirstTab(String url) {
        pageHost.removeAllViews();
        geckoView = new GeckoView(this);
        pageHost.addView(geckoView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        String initial = TextUtils.isEmpty(url) ? HOME_URL : url;
        addTab(false, initial);
    }

    private void showBrowserView() {
        if (pageHost == null || geckoView == null) return;
        if (geckoView.getParent() instanceof ViewGroup) {
            ((ViewGroup) geckoView.getParent()).removeView(geckoView);
        }
        pageHost.removeAllViews();
        pageHost.addView(geckoView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (activeTab != null && geckoView.getSession() == null) geckoView.setSession(activeTab.session);
    }

    private void addTab(boolean privateTab, String url) {
        if (!engineReady || runtime == null) {
            queuedStartUrl = url;
            toast("The browser is still starting");
            return;
        }
        GeckoSessionSettings sessionSettings = new GeckoSessionSettings.Builder()
                .usePrivateMode(privateTab)
                .allowJavascript(javascriptEnabled)
                .userAgentMode(desktopMode ? GeckoSessionSettings.USER_AGENT_MODE_DESKTOP : GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
                .build();
        GeckoSession session = new GeckoSession(sessionSettings);
        BrowserTab tab = new BrowserTab(session, privateTab);
        tab.desktop = desktopMode;
        session.setNavigationDelegate(new GeckoSession.NavigationDelegate() {
            @Override
            public void onLocationChange(GeckoSession changedSession, String newUrl,
                                         List<GeckoSession.PermissionDelegate.ContentPermission> permissions,
                                         Boolean hasUserGesture) {
                BrowserTab owner = findTab(changedSession);
                if (owner == null || newUrl == null) return;
                owner.url = newUrl;
                if (owner == activeTab) updateAddressBar();
                if (!owner.privateTab && !newUrl.startsWith("file:") && !newUrl.startsWith("data:") && !newUrl.startsWith("about:")) {
                    store.addVisit(owner.title, newUrl);
                }
                logEvent("Navigated: " + safeHost(newUrl));
            }

            @Override
            public void onCanGoBack(GeckoSession changedSession, boolean canGoBack) {
                BrowserTab owner = findTab(changedSession);
                if (owner != null) owner.canGoBack = canGoBack;
            }

            @Override
            public void onCanGoForward(GeckoSession changedSession, boolean canGoForward) {
                BrowserTab owner = findTab(changedSession);
                if (owner != null) owner.canGoForward = canGoForward;
            }

            @Override
            public GeckoResult<AllowOrDeny> onLoadRequest(GeckoSession changedSession, GeckoSession.NavigationDelegate.LoadRequest request) {
                return GeckoResult.fromValue(AllowOrDeny.ALLOW);
            }

            @Override
            public GeckoResult<GeckoSession> onNewSession(GeckoSession changedSession, String newUri) {
                BrowserTab newTab = addTabInternal(false, newUri, true);
                return GeckoResult.fromValue(newTab == null ? changedSession : newTab.session);
            }

            @Override
            public GeckoResult<String> onLoadError(GeckoSession changedSession, String uri, org.mozilla.geckoview.WebRequestError error) {
                logEvent("Page load error: " + safeHost(uri));
                if (changedSession == activeTabSession()) {
                    mainHandler.post(() -> toast("This page could not be loaded. Check the connection or Tor status."));
                }
                return GeckoResult.fromValue(null);
            }
        });
        session.setContentDelegate(new GeckoSession.ContentDelegate() {
            @Override
            public void onTitleChange(GeckoSession changedSession, String title) {
                BrowserTab owner = findTab(changedSession);
                if (owner == null) return;
                owner.title = TextUtils.isEmpty(title) ? owner.url : title;
                if (!owner.privateTab && !TextUtils.isEmpty(owner.url)) store.addVisit(owner.title, owner.url);
                if (owner == activeTab) updateAddressBar();
                refreshTabButton();
            }

            @Override
            public void onExternalResponse(GeckoSession changedSession, WebResponse response) {
                beginDownload(response);
            }
        });
        session.setProgressDelegate(new GeckoSession.ProgressDelegate() {
            @Override
            public void onPageStart(GeckoSession changedSession, String url) {
                BrowserTab owner = findTab(changedSession);
                if (owner == activeTab) setPageLoading(true);
                logEvent("Loading: " + safeHost(url));
            }

            @Override
            public void onPageStop(GeckoSession changedSession, boolean success) {
                BrowserTab owner = findTab(changedSession);
                if (owner == activeTab) setPageLoading(false);
                if (!success) logEvent("Page load did not complete.");
            }

            @Override
            public void onProgressChange(GeckoSession changedSession, int progress) {
                if (changedSession == activeTabSession()) updateLoadProgress(progress);
            }
        });
        session.open(runtime);
        tabs.add(tab);
        if (activeTab != null && geckoView != null && geckoView.getSession() != null) geckoView.releaseSession();
        activeTab = tab;
        if (geckoView != null) geckoView.setSession(session);
        updateAddressBar();
        refreshTabButton();
        if (!TextUtils.isEmpty(url)) session.loadUri(url);
        else session.loadUri(HOME_URL);
    }

    private BrowserTab addTabInternal(boolean privateTab, String url, boolean select) {
        if (!engineReady || runtime == null) return null;
        GeckoSessionSettings sessionSettings = new GeckoSessionSettings.Builder()
                .usePrivateMode(privateTab)
                .allowJavascript(javascriptEnabled)
                .userAgentMode(desktopMode ? GeckoSessionSettings.USER_AGENT_MODE_DESKTOP : GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
                .build();
        GeckoSession session = new GeckoSession(sessionSettings);
        BrowserTab tab = new BrowserTab(session, privateTab);
        tab.desktop = desktopMode;
        installDelegates(tab);
        session.open(runtime);
        tabs.add(tab);
        if (select) {
            if (geckoView != null && geckoView.getSession() != null) geckoView.releaseSession();
            activeTab = tab;
            if (geckoView != null) geckoView.setSession(session);
            updateAddressBar();
            refreshTabButton();
        }
        if (!TextUtils.isEmpty(url)) session.loadUri(url);
        else session.loadUri(HOME_URL);
        return tab;
    }

    private void installDelegates(BrowserTab tab) {
        GeckoSession session = tab.session;
        session.setNavigationDelegate(new GeckoSession.NavigationDelegate() {
            @Override
            public void onLocationChange(GeckoSession changedSession, String newUrl,
                                         List<GeckoSession.PermissionDelegate.ContentPermission> permissions,
                                         Boolean hasUserGesture) {
                BrowserTab owner = findTab(changedSession);
                if (owner == null || newUrl == null) return;
                owner.url = newUrl;
                if (owner == activeTab) updateAddressBar();
                if (!owner.privateTab && !newUrl.startsWith("file:") && !newUrl.startsWith("data:") && !newUrl.startsWith("about:")) store.addVisit(owner.title, newUrl);
                logEvent("Navigated: " + safeHost(newUrl));
            }
            @Override public void onCanGoBack(GeckoSession s, boolean value) { BrowserTab t = findTab(s); if (t != null) t.canGoBack = value; }
            @Override public void onCanGoForward(GeckoSession s, boolean value) { BrowserTab t = findTab(s); if (t != null) t.canGoForward = value; }
            @Override public GeckoResult<AllowOrDeny> onLoadRequest(GeckoSession s, GeckoSession.NavigationDelegate.LoadRequest request) { return GeckoResult.fromValue(AllowOrDeny.ALLOW); }
            @Override public GeckoResult<GeckoSession> onNewSession(GeckoSession s, String uri) {
                BrowserTab next = addTabInternal(false, uri, true);
                return GeckoResult.fromValue(next == null ? s : next.session);
            }
            @Override public GeckoResult<String> onLoadError(GeckoSession s, String uri, org.mozilla.geckoview.WebRequestError error) {
                logEvent("Page load error: " + safeHost(uri));
                if (s == activeTabSession()) mainHandler.post(() -> toast("This page could not be loaded. Check the connection or Tor status."));
                return GeckoResult.fromValue(null);
            }
        });
        session.setContentDelegate(new GeckoSession.ContentDelegate() {
            @Override public void onTitleChange(GeckoSession s, String title) {
                BrowserTab t = findTab(s);
                if (t == null) return;
                t.title = TextUtils.isEmpty(title) ? t.url : title;
                if (!t.privateTab && !TextUtils.isEmpty(t.url)) store.addVisit(t.title, t.url);
                if (t == activeTab) updateAddressBar();
                refreshTabButton();
            }
            @Override public void onExternalResponse(GeckoSession s, WebResponse response) { beginDownload(response); }
        });
        session.setProgressDelegate(new GeckoSession.ProgressDelegate() {
            @Override public void onPageStart(GeckoSession s, String url) {
                if (findTab(s) == activeTab) setPageLoading(true);
                logEvent("Loading: " + safeHost(url));
            }
            @Override public void onPageStop(GeckoSession s, boolean success) {
                if (findTab(s) == activeTab) setPageLoading(false);
                if (!success) logEvent("Page load did not complete.");
            }
            @Override public void onProgressChange(GeckoSession s, int progress) { if (s == activeTabSession()) updateLoadProgress(progress); }
        });
    }

    private BrowserTab findTab(GeckoSession session) {
        for (BrowserTab tab : tabs) if (tab.session == session) return tab;
        return null;
    }

    private GeckoSession activeTabSession() { return activeTab == null ? null : activeTab.session; }

    private void navigateFromAddressBar() {
        String input = addressField.getText().toString().trim();
        if (input.isEmpty()) return;
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(addressField.getWindowToken(), 0);
        addressField.clearFocus();
        openInCurrentTab(normalizeInput(input));
    }

    private String normalizeInput(String input) {
        String value = input.trim();
        if (value.matches("(?i)^(https?|file|about|view-source):.*")) return value;
        if (value.contains(" ") || !value.contains(".")) {
            try { return SEARCH_URL + java.net.URLEncoder.encode(value, "UTF-8"); }
            catch (Exception ignored) { return SEARCH_URL + value.replace(" ", "+"); }
        }
        if (value.startsWith(".onion") || value.endsWith(".onion") || value.contains(".onion/")) return "http://" + value;
        return "https://" + value;
    }

    private void openInCurrentTab(String url) {
        if (activeTab == null) {
            addTab(false, url);
            return;
        }
        activeTab.session.loadUri(normalizeInput(url));
    }

    private void goBack() {
        if (activeTab != null && activeTab.canGoBack) activeTab.session.goBack();
        else toast("No previous page");
    }

    private void goForward() {
        if (activeTab != null && activeTab.canGoForward) activeTab.session.goForward();
        else toast("No forward page");
    }

    private void reloadCurrent() {
        if (activeTab == null) return;
        if (pageLoading) activeTab.session.stop();
        else activeTab.session.reload();
    }

    private void updateAddressBar() {
        if (activeTab == null || addressField == null) return;
        String url = activeTab.url;
        if (url == null || HOME_URL.equals(url) || url.startsWith("file:///android_asset/start.html")) {
            addressField.setText("");
        } else {
            addressField.setText(displayAddress(url));
        }
        addressField.setSelection(addressField.getText().length());
        updateBookmarkButton();
        refreshTabButton();
        updatePrivacyUi();
    }

    private String displayAddress(String url) {
        if (url == null || url.isEmpty() || url.equals(HOME_URL) || url.startsWith("file:///android_asset/start.html")) return "Start page";
        try {
            Uri uri = Uri.parse(url.startsWith("view-source:") ? url.substring(12) : url);
            String host = uri.getHost();
            if (host == null) return url;
            String path = uri.getEncodedPath();
            if (path == null || path.equals("/")) return host + (uri.getEncodedQuery() == null ? "" : "?" + uri.getEncodedQuery());
            return host + path + (uri.getEncodedQuery() == null ? "" : "?" + uri.getEncodedQuery());
        } catch (Exception e) { return url; }
    }

    private void updatePrivacyUi() {
        if (routeText == null) return;
        if (torEnabled && torReady) {
            routeText.setText("Onion-routed  ·  Tor connected");
            routeText.setTextColor(ACCENT);
            onionMark.setTextColor(ACCENT);
        } else if (torEnabled) {
            routeText.setText("Tor starting  ·  direct fallback blocked");
            routeText.setTextColor(PURPLE);
            onionMark.setTextColor(PURPLE);
        } else {
            routeText.setText("Direct connection  ·  Tor is off");
            routeText.setTextColor(RED);
            onionMark.setTextColor(MUTED);
        }
    }

    private void setPageLoading(boolean loading) {
        pageLoading = loading;
        if (progressBar != null) progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
    }

    private void updateLoadProgress(int progress) {
        if (progressBar == null) return;
        if (progress >= 100) {
            progressBar.setVisibility(View.GONE);
        } else {
            progressBar.setVisibility(View.VISIBLE);
            ViewGroup.LayoutParams lp = progressBar.getLayoutParams();
            lp.width = Math.max(dp(24), (int) (getResources().getDisplayMetrics().widthPixels * Math.min(100, Math.max(0, progress)) / 100f));
            progressBar.setLayoutParams(lp);
        }
    }

    private void updateBookmarkButton() {
        if (bookmarkButton == null || activeTab == null) return;
        boolean bookmarked = store.isBookmarked(activeTab.url);
        bookmarkButton.setText(bookmarked ? "★" : "☆");
        bookmarkButton.setTextColor(bookmarked ? ACCENT : TEXT);
    }

    private void refreshTabButton() {
        if (tabButton != null) tabButton.setText("▢ " + Math.max(1, tabs.size()));
    }

    private void toggleBookmark() {
        if (activeTab == null || activeTab.url == null || HOME_URL.equals(activeTab.url)) {
            toast("Open a page first to bookmark it");
            return;
        }
        store.toggleBookmark(activeTab.title, activeTab.url);
        updateBookmarkButton();
        toast(store.isBookmarked(activeTab.url) ? "Bookmark saved" : "Bookmark removed");
        logEvent("Bookmark updated.");
    }

    private void showBrowserMenu() {
        if (isFinishing()) return;
        Dialog dialog = new Dialog(this);
        openMenuDialog = dialog;
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(18), dp(16), dp(18), dp(20));
        sheet.setBackground(roundedTop(SURFACE, 26));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = makeText("ONION MINI", 12, ACCENT, true);
        name.setLetterSpacing(0.14f);
        titleRow.addView(name, new LinearLayout.LayoutParams(0, dp(30), 1f));
        TextView close = makeText("✕", 20, MUTED, false);
        close.setGravity(Gravity.CENTER);
        close.setBackground(selectableBackground());
        titleRow.addView(close, new LinearLayout.LayoutParams(dp(38), dp(38)));
        close.setOnClickListener(v -> dialog.dismiss());
        sheet.addView(titleRow);

        TextView caption = makeText("Fast controls", 13, MUTED, false);
        LinearLayout.LayoutParams capLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(26));
        capLp.topMargin = dp(3);
        sheet.addView(caption, capLp);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        addMenuTile(row1, "▣", "Copy link", () -> copyCurrentLink());
        addMenuTile(row1, "⌕", "Find", () -> showFindDialog());
        addMenuTile(row1, "Tt", "Text size", () -> showTextSizeDialog());
        sheet.addView(row1, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(100)));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        addMenuTile(row2, "▤", desktopMode ? "Mobile site" : "Desktop site", () -> toggleDesktopMode());
        addMenuTile(row2, "↗", "Add to Home", () -> pinCurrentPage());
        addMenuTile(row2, "⇧", "Open in app", () -> openExternal());
        LinearLayout.LayoutParams row2Lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(100));
        row2Lp.topMargin = dp(8);
        sheet.addView(row2, row2Lp);

        TextView privacyHeader = makeText("Privacy", 16, TEXT, true);
        LinearLayout.LayoutParams privacyHeaderLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        privacyHeaderLp.topMargin = dp(14);
        sheet.addView(privacyHeader, privacyHeaderLp);

        LinearLayout privacyCard = new LinearLayout(this);
        privacyCard.setOrientation(LinearLayout.VERTICAL);
        privacyCard.setPadding(dp(16), dp(8), dp(12), dp(8));
        privacyCard.setBackground(rounded(CARD, 24));
        LinearLayout privacyRow = new LinearLayout(this);
        privacyRow.setOrientation(LinearLayout.HORIZONTAL);
        privacyRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView privacyIcon = makeText("◉", 27, PURPLE, true);
        privacyIcon.setGravity(Gravity.CENTER);
        privacyRow.addView(privacyIcon, new LinearLayout.LayoutParams(dp(48), dp(54)));
        LinearLayout privacyCopy = new LinearLayout(this);
        privacyCopy.setOrientation(LinearLayout.VERTICAL);
        privacyCopy.setPadding(dp(10), dp(4), dp(4), dp(4));
        TextView privacyTitle = makeText("Onion routing", 16, TEXT, true);
        TextView privacySubtitle = makeText(torEnabled ? (torReady ? "Web traffic is using Tor" : "Starting Tor; no direct fallback") : "Websites can see your network IP", 12, MUTED, false);
        privacyCopy.addView(privacyTitle);
        privacyCopy.addView(privacySubtitle);
        privacyRow.addView(privacyCopy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Switch torSwitch = new Switch(this);
        torSwitch.setChecked(torEnabled);
        torSwitch.setContentDescription("Onion routing");
        torSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (checked) {
                dialog.dismiss();
                enableTorRouting();
            } else {
                dialog.dismiss();
                confirmDisableTor();
            }
        });
        privacyRow.addView(torSwitch);
        privacyCard.addView(privacyRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)));

        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(61, 62, 71));
        privacyCard.addView(divider, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        LinearLayout newCircuit = menuRow("⟳", "New Tor circuit", "Request a fresh Tor identity");
        privacyCard.addView(newCircuit, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        newCircuit.setOnClickListener(v -> { dialog.dismiss(); requestNewCircuit(); });
        String bridgeSubtitle = preferences.getString(PREF_TOR_BRIDGES, "").isEmpty()
                ? "Add obfs4 bridges if this network blocks Tor" : "Obfs4 bridges saved on this device";
        addMenuRow(privacyCard, "◇", "Tor bridges", bridgeSubtitle, () -> { dialog.dismiss(); showTorBridgesDialog(); });
        addMenuRow(privacyCard, "✓", "Test Tor connection", "Check this route; never try direct internet", () -> { dialog.dismiss(); testTorConnection(); });
        sheet.addView(privacyCard, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView toolsHeader = makeText("Browser tools", 16, TEXT, true);
        LinearLayout.LayoutParams toolsHeaderLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        toolsHeaderLp.topMargin = dp(12);
        sheet.addView(toolsHeader, toolsHeaderLp);

        LinearLayout toolsCard = new LinearLayout(this);
        toolsCard.setOrientation(LinearLayout.VERTICAL);
        toolsCard.setBackground(rounded(CARD, 22));
        addMenuRow(toolsCard, "◷", "History", "Recently visited pages", () -> { dialog.dismiss(); showEntries("History", store.history(), true); });
        addMenuRow(toolsCard, "★", "Bookmarks", "Saved pages", () -> { dialog.dismiss(); showEntries("Bookmarks", store.bookmarks(), false); });
        addMenuRow(toolsCard, "↓", "Downloads", "Files saved through this browser", () -> { dialog.dismiss(); showDownloads(); });
        addMenuRow(toolsCard, "⚙", "Site settings", "Permissions and site data", () -> { dialog.dismiss(); showSiteSettings(); });
        addMenuRow(toolsCard, "⌘", "Web developer", "Page info, source and event console", () -> { dialog.dismiss(); showDeveloperTools(); });
        addMenuRow(toolsCard, "▤", "Clear browsing data", "Cookies, cache, history and site storage", () -> { dialog.dismiss(); confirmClearData(); });
        addMenuRow(toolsCard, "⚙", "Settings", "Search, privacy and browser behavior", () -> { dialog.dismiss(); showSettings(); });
        sheet.addView(toolsCard, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView about = makeText("A compact GeckoView browser with embedded Tor and optional obfs4 bridges. Routing is browser-only, not a system VPN. Not affiliated with the Tor Project.", 11, MUTED, false);
        about.setGravity(Gravity.CENTER);
        about.setPadding(dp(14), dp(16), dp(14), dp(4));
        sheet.addView(about, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.addView(sheet);
        dialog.setContentView(scroll);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            window.setGravity(Gravity.BOTTOM);
            WindowManager.LayoutParams params = window.getAttributes();
            params.width = ViewGroup.LayoutParams.MATCH_PARENT;
            params.height = Math.min((int)(getResources().getDisplayMetrics().heightPixels * 0.88f), dp(760));
            params.gravity = Gravity.BOTTOM;
            params.dimAmount = 0.58f;
            window.setAttributes(params);
        }
        dialog.setOnDismissListener(d -> { if (openMenuDialog == dialog) openMenuDialog = null; });
        dialog.show();
        if (dialog.getWindow() != null) dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, Math.min((int)(getResources().getDisplayMetrics().heightPixels * 0.88f), dp(760)));
    }

    private void addMenuTile(LinearLayout row, String glyph, String label, Runnable action) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(5), dp(4), dp(5), dp(4));
        tile.setBackground(rounded(CARD, 20));
        TextView icon = makeText(glyph, glyph.length() > 1 ? 22 : 26, TEXT, false);
        icon.setGravity(Gravity.CENTER);
        tile.addView(icon, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        TextView title = makeText(label, 11, TEXT, false);
        title.setGravity(Gravity.CENTER);
        tile.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));
        tile.setOnClickListener(v -> { if (openMenuDialog != null) openMenuDialog.dismiss(); action.run(); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(dp(4), dp(2), dp(4), dp(2));
        row.addView(tile, lp);
    }

    private void addMenuRow(LinearLayout parent, String glyph, String title, String subtitle, Runnable click) {
        LinearLayout row = menuRow(glyph, title, subtitle);
        parent.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)));
        row.setOnClickListener(v -> click.run());
    }

    private LinearLayout menuRow(String glyph, String title, String subtitle) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(6), dp(14), dp(6));
        row.setBackground(selectableBackground());
        TextView icon = makeText(glyph, 22, MUTED, true);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(36), ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams labelsLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        labelsLp.leftMargin = dp(12);
        row.addView(labels, labelsLp);
        labels.addView(makeText(title, 14, TEXT, true));
        labels.addView(makeText(subtitle, 11, MUTED, false));
        TextView arrow = makeText("›", 25, MUTED, false);
        arrow.setGravity(Gravity.CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(dp(24), ViewGroup.LayoutParams.MATCH_PARENT));
        return row;
    }

    private void enableTorRouting() {
        if (torEnabled && torReady) { toast("Tor is already connected"); return; }
        torEnabled = true;
        torReady = false;
        preferences.edit().putBoolean(PREF_TOR, true).apply();
        updatePrivacyUi();
        logEvent("User enabled onion routing.");
        if (runtime != null) {
            for (BrowserTab tab : tabs) {
                try { tab.session.stop(); } catch (Exception ignored) { }
            }
            showPlaceholder("Connecting to Tor", "Traffic is blocked until the Tor circuit is ready.", false);
            configureProxy(true, 1, false);
        }
        startTorService();
    }

    private void confirmDisableTor() {
        new AlertDialog.Builder(this)
                .setTitle("Turn off onion routing?")
                .setMessage("With Tor off, websites may see your ordinary network IP address. This is a direct connection, not an anonymous one.")
                .setNegativeButton("Keep Tor on", (d, w) -> { })
                .setPositiveButton("Turn off", (d, w) -> disableTorRouting())
                .show();
    }

    private void disableTorRouting() {
        torEnabled = false;
        torReady = false;
        preferences.edit().putBoolean(PREF_TOR, false).apply();
        updatePrivacyUi();
        logEvent("User turned Tor routing off; direct browsing enabled.");
        if (runtime == null) {
            stopTorService();
            createEngine(false, -1);
        } else {
            for (BrowserTab tab : tabs) {
                try { tab.session.stop(); } catch (Exception ignored) { }
            }
            configureProxy(false, -1, true);
            stopTorService();
        }
    }

    private void requestNewCircuit() {
        if (!torEnabled || !torReady || torService == null) {
            toast("Connect to Tor first");
            return;
        }
        try {
            TorControlConnection control = torService.getTorControlConnection();
            if (control != null) control.signal("NEWNYM");
            if (activeTab != null) activeTab.session.reload();
            logEvent("Requested a new Tor circuit (NEWNYM).");
            toast("Requested a new Tor circuit");
        } catch (Exception e) {
            logEvent("New circuit request failed: " + e.getMessage());
            toast("Could not request a new circuit");
        }
    }

    private void testTorConnection() {
        if (!torEnabled || !torReady || torPort <= 0) {
            new AlertDialog.Builder(this)
                    .setTitle("Tor is not connected")
                    .setMessage("Wait for the Tor circuit to be ready, then run this check. No direct-network test will be made.")
                    .setPositiveButton("OK", null)
                    .show();
            return;
        }
        final int testPort = torPort;
        logEvent("Started Tor-only connectivity check (SOCKS5 remote-DNS request).");
        toast("Testing through Tor only…");
        torTestWorker.execute(() -> {
            String result;
            boolean confirmed = false;
            try {
                confirmed = runTorExitCheck(testPort);
                result = confirmed
                        ? "The embedded Tor SOCKS endpoint reached the Tor Project check endpoint, which recognized the exit as Tor. This confirms Tor reachability from the app process, but does not test GeckoView page loads."
                        : "The check endpoint did not confirm a Tor exit. The app did not try a direct connection.";
            } catch (Exception error) {
                String detail = error.getMessage();
                result = "The Tor-only check failed" + (TextUtils.isEmpty(detail) ? "." : ": " + detail)
                        + " No direct connection was attempted.";
            }
            final String message = result;
            final boolean passed = confirmed;
            mainHandler.post(() -> {
                logEvent("Tor-only connectivity check " + (passed ? "passed." : "failed."));
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle(passed ? "Tor transport confirmed" : "Tor route not confirmed")
                        .setMessage(message)
                        .setPositiveButton("Done", null)
                        .show();
            });
        });
    }

    private boolean runTorExitCheck(int port) throws Exception {
        final String host = "check.torproject.org";
        Socket proxySocket = new Socket();
        SSLSocket tlsSocket = null;
        try {
            proxySocket.connect(new InetSocketAddress("127.0.0.1", port), 8_000);
            proxySocket.setSoTimeout(25_000);
            InputStream socksIn = proxySocket.getInputStream();
            OutputStream socksOut = proxySocket.getOutputStream();

            socksOut.write(new byte[]{0x05, 0x01, 0x00});
            socksOut.flush();
            if (readSocksByte(socksIn) != 0x05 || readSocksByte(socksIn) != 0x00) {
                throw new IOException("The local SOCKS5 proxy did not accept unauthenticated browser traffic.");
            }

            byte[] hostBytes = host.getBytes(StandardCharsets.US_ASCII);
            socksOut.write(new byte[]{0x05, 0x01, 0x00, 0x03, (byte) hostBytes.length});
            socksOut.write(hostBytes);
            socksOut.write(new byte[]{0x01, (byte) 0xBB});
            socksOut.flush();
            int version = readSocksByte(socksIn);
            int reply = readSocksByte(socksIn);
            readSocksByte(socksIn);
            int addressType = readSocksByte(socksIn);
            if (version != 0x05 || reply != 0x00) throw new IOException("Tor refused the remote connection (SOCKS reply " + reply + ").");
            if (addressType == 0x01) skipSocksBytes(socksIn, 4);
            else if (addressType == 0x03) skipSocksBytes(socksIn, readSocksByte(socksIn));
            else if (addressType == 0x04) skipSocksBytes(socksIn, 16);
            else throw new IOException("The SOCKS5 proxy returned an unknown address type.");
            skipSocksBytes(socksIn, 2);

            tlsSocket = (SSLSocket) ((SSLSocketFactory) SSLSocketFactory.getDefault())
                    .createSocket(proxySocket, host, 443, true);
            tlsSocket.setSoTimeout(25_000);
            tlsSocket.startHandshake();
            String request = "GET /api/ip HTTP/1.1\r\nHost: " + host
                    + "\r\nAccept: application/json\r\nConnection: close\r\n\r\n";
            tlsSocket.getOutputStream().write(request.getBytes(StandardCharsets.US_ASCII));
            tlsSocket.getOutputStream().flush();
            ByteArrayOutputStream responseBytes = new ByteArrayOutputStream();
            byte[] buffer = new byte[2048];
            int total = 0;
            int read;
            while (total < 16_384 && (read = tlsSocket.getInputStream().read(buffer, 0, Math.min(buffer.length, 16_384 - total))) != -1) {
                responseBytes.write(buffer, 0, read);
                total += read;
            }
            String responseText = new String(responseBytes.toByteArray(), StandardCharsets.UTF_8);
            int bodyStart = responseText.indexOf("\r\n\r\n");
            if (bodyStart < 0) throw new IOException("The Tor check endpoint returned an incomplete response.");
            String headers = responseText.substring(0, bodyStart);
            String[] headerLines = headers.split("\\r\\n");
            if (headerLines.length == 0 || !headerLines[0].matches("HTTP/1\\.[01] 200(?: .*)?")) {
                throw new IOException("Tor check endpoint returned " + (headerLines.length == 0 ? "an invalid status" : headerLines[0]) + ".");
            }
            String body = responseText.substring(bodyStart + 4).trim();
            if (headers.toLowerCase(Locale.ROOT).contains("transfer-encoding: chunked")) body = decodeChunkedBody(body);
            JSONObject json = new JSONObject(body);
            return json.optBoolean("IsTor", false);
        } finally {
            if (tlsSocket != null) {
                try { tlsSocket.close(); } catch (IOException ignored) { }
            }
            try { proxySocket.close(); } catch (IOException ignored) { }
        }
    }

    private int readSocksByte(InputStream input) throws IOException {
        int value = input.read();
        if (value < 0) throw new EOFException("The local SOCKS5 proxy closed the connection.");
        return value;
    }

    private void skipSocksBytes(InputStream input, int count) throws IOException {
        while (count > 0) {
            long skipped = input.skip(count);
            if (skipped > 0) count -= (int) skipped;
            else { readSocksByte(input); count--; }
        }
    }

    private String decodeChunkedBody(String body) throws IOException {
        StringBuilder decoded = new StringBuilder();
        int cursor = 0;
        while (true) {
            int lineEnd = body.indexOf("\r\n", cursor);
            if (lineEnd < 0) throw new IOException("The Tor check response had invalid chunk framing.");
            String sizeText = body.substring(cursor, lineEnd);
            int extension = sizeText.indexOf(';');
            if (extension >= 0) sizeText = sizeText.substring(0, extension);
            int size;
            try { size = Integer.parseInt(sizeText.trim(), 16); }
            catch (NumberFormatException error) { throw new IOException("The Tor check response had invalid chunk framing."); }
            cursor = lineEnd + 2;
            if (size == 0) break;
            if (size < 0 || cursor + size > body.length()) throw new IOException("The Tor check response was truncated.");
            decoded.append(body, cursor, cursor + size);
            cursor += size;
            if (body.startsWith("\r\n", cursor)) cursor += 2;
        }
        return decoded.toString();
    }

    private void showTorBridgesDialog() {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(4), dp(20), dp(8));
        TextView instructions = makeText("If Tor stays stuck on a network that blocks Tor, paste one or more full obfs4 bridge lines below. Get them from the Tor Project or another source you trust. Lines are stored on this device only.\n\nAccepted format: obfs4 IP:PORT FINGERPRINT cert=… iat-mode=0", 13, MUTED, false);
        content.addView(instructions, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        EditText input = new EditText(this);
        input.setSingleLine(false);
        input.setMinLines(4);
        input.setMaxLines(8);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setTextSize(12);
        input.setTypeface(android.graphics.Typeface.MONOSPACE);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setHint("Paste complete obfs4 bridge line(s)");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        input.setBackground(rounded(CARD, 14));
        input.setText(preferences.getString(PREF_TOR_BRIDGES, ""));
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150));
        inputLp.topMargin = dp(12);
        content.addView(input, inputLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Tor bridges · obfs4")
                .setView(content)
                .setPositiveButton("Save and restart Tor", null)
                .setNegativeButton("Cancel", null)
                .setNeutralButton("Clear bridges", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                try {
                    saveTorBridgeConfig(input.getText().toString());
                    dialog.dismiss();
                } catch (IllegalArgumentException error) {
                    input.setError(error.getMessage());
                }
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                input.setText("");
                try {
                    saveTorBridgeConfig("");
                    dialog.dismiss();
                } catch (IllegalArgumentException error) {
                    input.setError(error.getMessage());
                }
            });
        });
        dialog.show();
    }

    private void saveTorBridgeConfig(String raw) {
        String normalized = normalizeObfs4BridgeLines(raw);
        preferences.edit().putString(PREF_TOR_BRIDGES, normalized).apply();
        logEvent("Saved " + (normalized.isEmpty() ? "no" : normalized.split("\\n").length) + " obfs4 bridge(s) locally.");
        if (!torEnabled) {
            toast(normalized.isEmpty() ? "Tor bridges cleared" : "Bridge lines saved. They will be used when Tor is enabled.");
            return;
        }
        torReady = false;
        torPort = -1;
        torError = null;
        torBootstrapHintShown = false;
        mainHandler.removeCallbacks(torBootstrapPoll);
        for (BrowserTab tab : tabs) {
            try { tab.session.stop(); } catch (Exception ignored) { }
        }
        showPlaceholder("Restarting Tor", "Applying the bridge configuration. Web traffic remains blocked until Tor connects.", false);
        if (runtime != null) configureProxy(true, 1, false);
        stopTorService();
        mainHandler.postDelayed(() -> {
            if (!isFinishing()) startTorService();
        }, 800);
    }

    private void copyCurrentLink() {
        if (activeTab == null || TextUtils.isEmpty(activeTab.url) || HOME_URL.equals(activeTab.url)) {
            toast("There is no page link to copy");
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Page link", activeTab.url));
        toast("Link copied");
    }

    private void openExternal() {
        if (activeTab == null || TextUtils.isEmpty(activeTab.url) || HOME_URL.equals(activeTab.url)) {
            toast("Open a page first");
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(activeTab.url));
            startActivity(Intent.createChooser(intent, "Open with"));
        } catch (Exception e) { toast("No compatible app found"); }
    }

    private void pinCurrentPage() {
        if (activeTab == null || HOME_URL.equals(activeTab.url)) { toast("Open a page first"); return; }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) { toast("Pinned shortcuts need Android 8 or newer"); return; }
        ShortcutManager manager = getSystemService(ShortcutManager.class);
        if (manager == null || !manager.isRequestPinShortcutSupported()) { toast("Home-screen shortcuts are unavailable"); return; }
        String label = TextUtils.isEmpty(activeTab.title) ? safeHost(activeTab.url) : activeTab.title;
        Intent shortcutIntent = new Intent(this, MainActivity.class).setAction(Intent.ACTION_VIEW).setData(Uri.parse(activeTab.url));
        ShortcutInfo shortcut = new ShortcutInfo.Builder(this, "page-" + Math.abs(activeTab.url.hashCode()))
                .setShortLabel(label.length() > 20 ? label.substring(0, 20) : label)
                .setLongLabel(label)
                .setIntent(shortcutIntent)
                .setIcon(android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_app))
                .build();
        PendingIntent callback = PendingIntent.getBroadcast(this, 0, new Intent("com.onionmini.browser.SHORTCUT_PINNED"), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        manager.requestPinShortcut(shortcut, callback.getIntentSender());
        toast("Shortcut request sent to your launcher");
    }

    private void showFindDialog() {
        if (activeTab == null) { toast("Open a page first"); return; }
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(12), dp(20), dp(10));
        EditText query = new EditText(this);
        query.setSingleLine(true);
        query.setHint("Find on this page");
        content.addView(query, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        TextView previous = makeDialogButton("Previous");
        TextView next = makeDialogButton("Next");
        TextView done = makeDialogButton("Done");
        buttons.addView(previous, new LinearLayout.LayoutParams(0, dp(48), 1f));
        buttons.addView(next, new LinearLayout.LayoutParams(0, dp(48), 1f));
        buttons.addView(done, new LinearLayout.LayoutParams(0, dp(48), 1f));
        content.addView(buttons);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Find in page").setView(content).create();
        Runnable findNext = () -> {
            String q = query.getText().toString();
            if (!q.isEmpty()) {
                activeTab.session.getFinder().setDisplayFlags(GeckoSession.FINDER_DISPLAY_HIGHLIGHT_ALL);
                activeTab.session.getFinder().find(q, GeckoSession.FINDER_FIND_FORWARD);
            }
        };
        next.setOnClickListener(v -> findNext.run());
        previous.setOnClickListener(v -> {
            String q = query.getText().toString();
            if (!q.isEmpty()) activeTab.session.getFinder().find(q, GeckoSession.FINDER_FIND_BACKWARDS);
        });
        done.setOnClickListener(v -> { if (activeTab != null) activeTab.session.getFinder().clear(); dialog.dismiss(); });
        dialog.setOnDismissListener(d -> { if (activeTab != null) activeTab.session.getFinder().clear(); });
        dialog.show();
        query.requestFocus();
    }

    private void showTextSizeDialog() {
        String[] choices = {"Smaller  −", "Default  100%", "Larger  +"};
        new AlertDialog.Builder(this)
                .setTitle("Text size")
                .setSingleChoiceItems(choices, fontFactor < 0.95f ? 0 : (fontFactor > 1.05f ? 2 : 1), (dialog, which) -> {
                    fontFactor = which == 0 ? 0.85f : (which == 2 ? 1.20f : 1.0f);
                    preferences.edit().putFloat(PREF_FONT, fontFactor).apply();
                    if (runtime != null) runtime.getSettings().setFontSizeFactor(fontFactor);
                    if (activeTab != null) activeTab.session.reload();
                    dialog.dismiss();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toggleDesktopMode() {
        desktopMode = !desktopMode;
        if (activeTab != null) {
            activeTab.desktop = desktopMode;
            activeTab.session.getSettings().setUserAgentMode(desktopMode ? GeckoSessionSettings.USER_AGENT_MODE_DESKTOP : GeckoSessionSettings.USER_AGENT_MODE_MOBILE);
            activeTab.session.reload();
        }
        toast(desktopMode ? "Desktop site requested" : "Mobile site requested");
        logEvent("User agent switched to " + (desktopMode ? "desktop" : "mobile") + ".");
    }

    private void showSiteSettings() {
        String url = activeTab == null ? "" : activeTab.url;
        String host = safeHost(url);
        String[] options = {"Page information", "Clear cookies and site data for " + host, "JavaScript: " + (javascriptEnabled ? "On" : "Off")};
        new AlertDialog.Builder(this)
                .setTitle("Site settings")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) showPageInfo();
                    else if (which == 1) clearCurrentSiteData(host);
                    else toggleJavaScript();
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void clearCurrentSiteData(String host) {
        if (runtime == null || TextUtils.isEmpty(host) || host.equals("Start page")) { toast("No site data to clear"); return; }
        new AlertDialog.Builder(this)
                .setTitle("Clear site data?")
                .setMessage("Remove cookies, cache and stored site data for " + host + "?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear", (d, w) -> {
                    runtime.getStorageController().clearDataFromHost(host, StorageController.ClearFlags.ALL)
                            .accept(value -> mainHandler.post(() -> toast("Site data cleared")), error -> mainHandler.post(() -> toast("Could not clear site data")));
                }).show();
    }

    private void toggleJavaScript() {
        javascriptEnabled = !javascriptEnabled;
        for (BrowserTab tab : tabs) tab.session.getSettings().setAllowJavascript(javascriptEnabled);
        if (activeTab != null) activeTab.session.reload();
        toast("JavaScript " + (javascriptEnabled ? "enabled" : "disabled"));
    }

    private void showDeveloperTools() {
        String[] items = {"Page information", "View page source", "Browser event console", "Toggle JavaScript"};
        new AlertDialog.Builder(this)
                .setTitle("Web developer")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) showPageInfo();
                    else if (which == 1) viewPageSource();
                    else if (which == 2) showEventConsole();
                    else toggleJavaScript();
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void showPageInfo() {
        String url = activeTab == null ? "" : activeTab.url;
        String title = activeTab == null ? "Start page" : activeTab.title;
        String scheme = url.startsWith("https:") ? "HTTPS secure connection" : (url.contains(".onion") ? "Onion service" : "Not HTTPS");
        String route = torEnabled ? (torReady ? "Tor SOCKS5, remote DNS enabled" : "Tor starting; direct fallback blocked") : "Direct connection; your network IP may be visible";
        String text = "Title: " + title + "\n\nAddress: " + url + "\n\nConnection: " + scheme + "\nRouting: " + route + "\nBrowser engine: GeckoView\n\nThis app is not the official Tor Browser.";
        new AlertDialog.Builder(this).setTitle("Page information").setMessage(text).setPositiveButton("Done", null).show();
    }

    private void viewPageSource() {
        if (activeTab == null || TextUtils.isEmpty(activeTab.url) || activeTab.url.startsWith("file:")) { toast("No web page source available"); return; }
        String target = activeTab.url.startsWith("view-source:") ? activeTab.url.substring(12) : "view-source:" + activeTab.url;
        openInCurrentTab(target);
    }

    private void showEventConsole() {
        StringBuilder body = new StringBuilder();
        if (eventLog.isEmpty()) body.append("No browser events yet.");
        else for (String entry : eventLog) body.append(entry).append("\n");
        new AlertDialog.Builder(this)
                .setTitle("Browser event console")
                .setMessage(body.toString())
                .setPositiveButton("Done", null)
                .setNeutralButton("Clear log", (d, w) -> { eventLog.clear(); toast("Event log cleared"); })
                .show();
    }

    private void showSettings() {
        String[] options = {"Search engine: DuckDuckGo", "Onion routing: " + (torEnabled ? "On" : "Off"), "Text size", "Clear browsing data", "About Onion Mini"};
        new AlertDialog.Builder(this).setTitle("Settings").setItems(options, (dialog, which) -> {
            if (which == 0) new AlertDialog.Builder(this).setTitle("Default search engine").setMessage("DuckDuckGo is used for address-bar searches in this build.").setPositiveButton("OK", null).show();
            else if (which == 1) { if (torEnabled) confirmDisableTor(); else enableTorRouting(); }
            else if (which == 2) showTextSizeDialog();
            else if (which == 3) confirmClearData();
            else showAbout();
        }).setNegativeButton("Close", null).show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this).setTitle("About Onion Mini")
                .setMessage("Onion Mini 1.1\n\nA compact Android browser built with Mozilla GeckoView and Guardian Project's embedded Tor service. It supports browser-scoped Tor routing, optional obfs4 bridges, onion URLs, tabs, private tabs, history, bookmarks, downloads, find-in-page and basic web developer tools. Tor is not a device-wide Android VPN.\n\nThis is an independent prototype, not an official Tor Browser. Tor routing alone does not guarantee anonymity or prevent browser fingerprinting.")
                .setPositiveButton("Done", null).show();
    }

    private void confirmClearData() {
        new AlertDialog.Builder(this)
                .setTitle("Clear browsing data?")
                .setMessage("This removes browser history, cookies, cached files, form data and site storage. Saved bookmarks and downloaded files are kept.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear data", (dialog, which) -> clearAllData())
                .show();
    }

    private void clearAllData() {
        store.clearHistory();
        if (runtime == null) { toast("History cleared"); return; }
        ArrayList<String> urls = new ArrayList<>();
        ArrayList<Boolean> privateFlags = new ArrayList<>();
        for (BrowserTab tab : tabs) {
            urls.add(TextUtils.isEmpty(tab.url) ? HOME_URL : tab.url);
            privateFlags.add(tab.privateTab);
        }
        closeAllSessions();
        runtime.getStorageController().clearData(StorageController.ClearFlags.ALL).accept(value -> mainHandler.post(() -> {
            tabs.clear();
            if (urls.isEmpty()) urls.add(HOME_URL);
            for (int i = 0; i < urls.size(); i++) addTab(privateFlags.get(i), urls.get(i));
            toast("Browsing data cleared");
            logEvent("Browsing data cleared.");
        }), error -> mainHandler.post(() -> toast("Could not clear all site data")));
    }

    private void closeAllSessions() {
        if (geckoView != null && geckoView.getSession() != null) geckoView.releaseSession();
        for (BrowserTab tab : new ArrayList<>(tabs)) {
            try { tab.session.close(); } catch (Exception ignored) { }
        }
        tabs.clear();
        activeTab = null;
    }

    private void showEntries(String title, List<BrowserStore.Entry> entries, boolean history) {
        Dialog dialog = new Dialog(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(18), dp(18), dp(18));
        panel.setBackground(rounded(SURFACE, 24));
        TextView heading = makeText(title, 20, TEXT, true);
        panel.addView(heading, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        ScrollView scroller = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        if (entries.isEmpty()) {
            TextView empty = makeText(history ? "No history yet." : "No bookmarks saved yet.", 14, MUTED, false);
            empty.setPadding(dp(4), dp(18), dp(4), dp(18));
            list.addView(empty);
        } else {
            for (BrowserStore.Entry entry : entries) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(6), dp(10), dp(6), dp(10));
                row.setBackground(selectableBackground());
                row.addView(makeText(entry.title, 14, TEXT, true));
                TextView url = makeText(entry.url, 11, MUTED, false);
                url.setMaxLines(2);
                url.setEllipsize(TextUtils.TruncateAt.END);
                row.addView(url);
                if (history) row.addView(makeText(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(entry.time)), 10, MUTED, false));
                row.setOnClickListener(v -> { dialog.dismiss(); if (history) openHistoryUrl(entry.url); else openInCurrentTab(entry.url); });
                row.setOnLongClickListener(v -> {
                    new AlertDialog.Builder(this).setItems(new String[]{"Open", history ? "Remove from history" : "Remove bookmark", "Copy link"}, (d, which) -> {
                        if (which == 0) { dialog.dismiss(); openInCurrentTab(entry.url); }
                        else if (which == 1) { if (history) store.deleteHistory(entry.id); else store.deleteBookmark(entry.url); dialog.dismiss(); showEntries(title, history ? store.history() : store.bookmarks(), history); }
                        else { copyText(entry.url); }
                    }).show();
                    return true;
                });
                list.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                View divider = new View(this);
                divider.setBackgroundColor(Color.rgb(56, 57, 66));
                list.addView(divider, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
            }
        }
        scroller.addView(list);
        panel.addView(scroller, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        if (history) {
            TextView clear = makeDialogButton("Clear history");
            clear.setOnClickListener(v -> { store.clearHistory(); dialog.dismiss(); toast("History cleared"); });
            buttons.addView(clear, new LinearLayout.LayoutParams(0, dp(48), 1f));
        }
        TextView done = makeDialogButton("Done");
        done.setOnClickListener(v -> dialog.dismiss());
        buttons.addView(done, new LinearLayout.LayoutParams(0, dp(48), 1f));
        panel.addView(buttons, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        dialog.setContentView(panel);
        Window win = dialog.getWindow();
        if (win != null) {
            win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, (int)(getResources().getDisplayMetrics().heightPixels * 0.78f));
        }
        dialog.show();
        if (dialog.getWindow() != null) dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, (int)(getResources().getDisplayMetrics().heightPixels * 0.78f));
    }

    private void openHistoryUrl(String url) {
        if (activeTab == null) addTab(false, url); else openInCurrentTab(url);
    }

    private void showTabs() {
        Dialog dialog = new Dialog(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(18), dp(18), dp(16));
        panel.setBackground(rounded(SURFACE, 24));
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = makeText("Tabs  ·  " + tabs.size(), 20, TEXT, true);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1f));
        TextView add = makeDialogButton("＋ New tab");
        header.addView(add, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)));
        add.setOnClickListener(v -> { dialog.dismiss(); addTab(false, HOME_URL); });
        panel.addView(header);
        ScrollView scroller = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        if (tabs.isEmpty()) list.addView(makeText("No tabs open", 14, MUTED, false));
        for (BrowserTab tab : new ArrayList<>(tabs)) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(8), dp(8), dp(8));
            row.setBackground(rounded(tab == activeTab ? CARD_HI : CARD, 16));
            LinearLayout label = new LinearLayout(this);
            label.setOrientation(LinearLayout.VERTICAL);
            label.addView(makeText((tab.privateTab ? "◉ Private  ·  " : "") + (TextUtils.isEmpty(tab.title) ? "New tab" : tab.title), 14, TEXT, true));
            TextView tabUrl = makeText(displayAddress(tab.url), 11, MUTED, false);
            tabUrl.setMaxLines(1);
            tabUrl.setEllipsize(TextUtils.TruncateAt.END);
            label.addView(tabUrl);
            row.addView(label, new LinearLayout.LayoutParams(0, dp(52), 1f));
            TextView close = makeText("✕", 18, MUTED, true);
            close.setGravity(Gravity.CENTER);
            close.setBackground(selectableBackground());
            row.addView(close, new LinearLayout.LayoutParams(dp(42), dp(42)));
            row.setOnClickListener(v -> { dialog.dismiss(); selectTab(tab); });
            close.setOnClickListener(v -> { closeTab(tab); dialog.dismiss(); showTabs(); });
            row.setOnLongClickListener(v -> { closeTab(tab); dialog.dismiss(); showTabs(); return true; });
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rowLp.topMargin = dp(7);
            list.addView(row, rowLp);
        }
        scroller.addView(list);
        panel.addView(scroller, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout bottom = new LinearLayout(this);
        TextView privateNew = makeDialogButton("＋ Private tab");
        privateNew.setOnClickListener(v -> { dialog.dismiss(); addTab(true, HOME_URL); });
        bottom.addView(privateNew, new LinearLayout.LayoutParams(0, dp(48), 1f));
        panel.addView(bottom, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        dialog.setContentView(panel);
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, (int)(getResources().getDisplayMetrics().heightPixels * 0.75f));
        }
    }

    private void selectTab(BrowserTab tab) {
        if (tab == null || !tabs.contains(tab)) return;
        if (geckoView != null && geckoView.getSession() != null) geckoView.releaseSession();
        activeTab = tab;
        geckoView.setSession(tab.session);
        updateAddressBar();
    }

    private void closeTab(BrowserTab tab) {
        if (tab == null || !tabs.contains(tab)) return;
        int index = tabs.indexOf(tab);
        boolean wasActive = tab == activeTab;
        if (wasActive && geckoView != null && geckoView.getSession() != null) geckoView.releaseSession();
        tabs.remove(tab);
        try { tab.session.close(); } catch (Exception ignored) { }
        if (tabs.isEmpty()) {
            addTab(false, HOME_URL);
        } else if (wasActive) {
            selectTab(tabs.get(Math.max(0, index - 1)));
        }
        refreshTabButton();
    }

    private void showDownloads() {
        List<BrowserStore.Entry> entries = store.downloads();
        if (entries.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Downloads").setMessage("No downloads saved yet. Files downloaded by pages are stored in this app's private Downloads folder, through the browser's current network route.").setPositiveButton("Done", null).show();
            return;
        }
        String[] names = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) names[i] = entries.get(i).title;
        new AlertDialog.Builder(this).setTitle("Downloads").setItems(names, (dialog, which) -> openDownloadedFile(entries.get(which))).setNegativeButton("Done", null).show();
    }

    private void beginDownload(WebResponse response) {
        InputStream stream = response.body;
        if (stream == null) {
            logEvent("Download response had no readable body.");
            toast("This download could not be saved");
            return;
        }
        String proposed = safeFilename(response.uri);
        logEvent("Download started: " + proposed);
        toast("Downloading " + proposed);
        downloadWorker.execute(() -> {
            File folder = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            if (folder == null) folder = new File(getFilesDir(), "downloads");
            if (!folder.exists()) folder.mkdirs();
            File output = new File(folder, proposed);
            int suffix = 1;
            while (output.exists()) {
                int dot = proposed.lastIndexOf('.');
                String rootName = dot > 0 ? proposed.substring(0, dot) : proposed;
                String ext = dot > 0 ? proposed.substring(dot) : "";
                output = new File(folder, rootName + "-" + suffix++ + ext);
            }
            try (InputStream in = stream; FileOutputStream out = new FileOutputStream(output)) {
                byte[] buffer = new byte[16 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                store.addDownload(output.getName(), output.getAbsolutePath());
                logEvent("Download saved: " + output.getName());
                File finalOutput = output;
                mainHandler.post(() -> toast("Saved to browser downloads: " + finalOutput.getName()));
            } catch (Exception e) {
                logEvent("Download failed: " + e.getMessage());
                mainHandler.post(() -> toast("Download failed"));
            }
        });
    }

    private String safeFilename(String url) {
        String name = "download-" + System.currentTimeMillis();
        try {
            String path = Uri.parse(url).getLastPathSegment();
            if (!TextUtils.isEmpty(path)) name = URLDecoder.decode(path, "UTF-8");
        } catch (Exception ignored) { }
        name = name.replaceAll("[^A-Za-z0-9._-]", "_");
        if (name.length() > 100) name = name.substring(name.length() - 100);
        if (!name.contains(".")) name += ".bin";
        return name;
    }

    private void openDownloadedFile(BrowserStore.Entry entry) {
        File file = new File(entry.url);
        if (!file.exists()) { toast("File is no longer available"); return; }
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", file);
            String mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(android.webkit.MimeTypeMap.getFileExtensionFromUrl(file.getName()));
            Intent intent = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime == null ? "application/octet-stream" : mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Open download"));
        } catch (Exception e) { toast("No app can open this file"); }
    }

    private void showClearHistory() {
        store.clearHistory();
        toast("History cleared");
    }

    private void confirmClearAllSiteData() {
        confirmClearData();
    }

    private void logEvent(String message) {
        String time = new java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        eventLog.addLast(time + "  " + message);
        while (eventLog.size() > 80) eventLog.removeFirst();
    }

    private void copyText(String value) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Copied text", value));
        toast("Copied");
    }

    private String safeHost(String url) {
        if (TextUtils.isEmpty(url)) return "Start page";
        try {
            Uri uri = Uri.parse(url.startsWith("view-source:") ? url.substring(12) : url);
            String host = uri.getHost();
            return host == null ? (url.startsWith("file:") ? "Start page" : url) : host;
        } catch (Exception e) { return url; }
    }

    private TextView makeText(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return view;
    }

    private TextView makeDialogButton(String text) {
        TextView button = makeText(text, 13, ACCENT, true);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(6), dp(6), dp(6), dp(6));
        button.setBackground(selectableBackground());
        return button;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private GradientDrawable roundedTop(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        float r = dp(radiusDp);
        drawable.setCornerRadii(new float[]{r,r,r,r,0,0,0,0});
        return drawable;
    }

    private android.graphics.drawable.Drawable selectableBackground() {
        android.util.TypedValue value = new android.util.TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, value, true);
        try { return getDrawable(value.resourceId); } catch (Exception e) { return new ColorDrawable(Color.TRANSPARENT); }
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }

    @Override
    public void onBackPressed() {
        if (addressField != null && addressField.hasFocus()) {
            addressField.clearFocus();
            ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(addressField.getWindowToken(), 0);
        } else if (activeTab != null && activeTab.canGoBack) {
            activeTab.session.goBack();
        } else if (tabs.size() > 1 && activeTab != null) {
            closeTab(activeTab);
        } else if (activeTab != null && !HOME_URL.equals(activeTab.url)) {
            activeTab.session.loadUri(HOME_URL);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (openMenuDialog != null) {
            try { openMenuDialog.dismiss(); } catch (Exception ignored) { }
            openMenuDialog = null;
        }
        if (isFinishing()) {
            closeAllSessions();
            stopTorService();
            if (runtime != null) {
                try { runtime.shutdown(); } catch (Exception ignored) { }
                runtime = null;
            }
            downloadWorker.shutdown();
            torMonitorWorker.shutdown();
            torTestWorker.shutdown();
        }
        super.onDestroy();
    }

    /** Android's newer receiver flags are handled here to keep the Activity readable. */
    private static final class IntentFilterCompat {
        static void registerTorReceiver(Activity activity, BroadcastReceiver receiver) {
            android.content.IntentFilter filter = new android.content.IntentFilter(TorService.ACTION_STATUS);
            filter.addAction(TorService.ACTION_ERROR);
            if (Build.VERSION.SDK_INT >= 33) activity.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
            else activity.registerReceiver(receiver, filter);
        }
    }
}
