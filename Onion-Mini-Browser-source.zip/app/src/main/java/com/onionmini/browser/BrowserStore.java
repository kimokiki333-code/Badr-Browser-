package com.onionmini.browser;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/** Small on-device store for regular-window history, bookmarks, and downloaded files. */
public final class BrowserStore extends SQLiteOpenHelper {
    private static final String DB_NAME = "onion_mini_browser.db";
    private static final int DB_VERSION = 1;

    public static final class Entry {
        public final long id;
        public final String title;
        public final String url;
        public final long time;

        Entry(long id, String title, String url, long time) {
            this.id = id;
            this.title = title == null || title.trim().isEmpty() ? url : title;
            this.url = url;
            this.time = time;
        }
    }

    public BrowserStore(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE history (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, url TEXT NOT NULL, visited_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX history_time_idx ON history(visited_at DESC)");
        db.execSQL("CREATE TABLE bookmarks (url TEXT PRIMARY KEY, title TEXT NOT NULL, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE downloads (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, path TEXT NOT NULL, saved_at INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // The first release uses schema version 1. Future migrations belong here.
    }

    public synchronized void addVisit(String title, String url) {
        if (url == null || url.isEmpty() || url.startsWith("about:") || url.startsWith("file:") || url.startsWith("data:")) return;
        SQLiteDatabase db = getWritableDatabase();
        try (Cursor last = db.rawQuery("SELECT url,visited_at FROM history ORDER BY visited_at DESC LIMIT 1", null)) {
            if (last.moveToFirst() && url.equals(last.getString(0)) && System.currentTimeMillis() - last.getLong(1) < 60_000L) return;
        }
        ContentValues values = new ContentValues();
        values.put("title", title == null || title.isEmpty() ? url : title);
        values.put("url", url);
        values.put("visited_at", System.currentTimeMillis());
        db.insert("history", null, values);
        db.execSQL("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY visited_at DESC LIMIT 500)");
    }

    public synchronized List<Entry> history() {
        return queryEntries("SELECT id,title,url,visited_at FROM history ORDER BY visited_at DESC LIMIT 300", null);
    }

    public synchronized void clearHistory() {
        getWritableDatabase().delete("history", null, null);
    }

    public synchronized void deleteHistory(long id) {
        getWritableDatabase().delete("history", "id=?", new String[]{String.valueOf(id)});
    }

    public synchronized boolean isBookmarked(String url) {
        if (url == null) return false;
        try (Cursor c = getReadableDatabase().rawQuery("SELECT 1 FROM bookmarks WHERE url=? LIMIT 1", new String[]{url})) {
            return c.moveToFirst();
        }
    }

    public synchronized void toggleBookmark(String title, String url) {
        if (url == null || url.isEmpty()) return;
        SQLiteDatabase db = getWritableDatabase();
        if (isBookmarked(url)) {
            db.delete("bookmarks", "url=?", new String[]{url});
        } else {
            ContentValues values = new ContentValues();
            values.put("url", url);
            values.put("title", title == null || title.isEmpty() ? url : title);
            values.put("created_at", System.currentTimeMillis());
            db.insertWithOnConflict("bookmarks", null, values, SQLiteDatabase.CONFLICT_REPLACE);
        }
    }

    public synchronized List<Entry> bookmarks() {
        return queryEntries("SELECT rowid,title,url,created_at FROM bookmarks ORDER BY created_at DESC", null);
    }

    public synchronized void deleteBookmark(String url) {
        getWritableDatabase().delete("bookmarks", "url=?", new String[]{url});
    }

    public synchronized void addDownload(String title, String path) {
        ContentValues values = new ContentValues();
        values.put("title", title == null || title.isEmpty() ? path : title);
        values.put("path", path);
        values.put("saved_at", System.currentTimeMillis());
        getWritableDatabase().insert("downloads", null, values);
    }

    public synchronized List<Entry> downloads() {
        return queryEntries("SELECT id,title,path,saved_at FROM downloads ORDER BY saved_at DESC", null);
    }

    public synchronized void deleteDownload(long id) {
        getWritableDatabase().delete("downloads", "id=?", new String[]{String.valueOf(id)});
    }

    private List<Entry> queryEntries(String sql, String[] args) {
        ArrayList<Entry> result = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(sql, args)) {
            while (c.moveToNext()) {
                result.add(new Entry(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3)));
            }
        }
        return result;
    }
}
