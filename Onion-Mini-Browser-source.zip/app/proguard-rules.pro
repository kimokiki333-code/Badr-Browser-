# Keep embedded Tor JNI service and GeckoView runtime classes intact.
-keep class org.torproject.jni.** { *; }
-keep class org.mozilla.geckoview.** { *; }
