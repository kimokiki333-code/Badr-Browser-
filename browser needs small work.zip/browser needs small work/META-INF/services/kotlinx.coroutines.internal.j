q3.a
