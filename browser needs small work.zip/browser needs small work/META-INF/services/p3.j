q3.b
